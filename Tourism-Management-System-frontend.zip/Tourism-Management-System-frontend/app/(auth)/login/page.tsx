'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth, AuthProvider } from '@/contexts/AuthContext';

// Admin Dashboard components
import DashboardContent from '@/app/(protected)/admin/components/DashboardContent';
import SettingsContent from '@/app/(protected)/admin/components/SettingsContent';
import ToursContent from '@/app/(protected)/admin/components/PackageContent';

import { fetchTours } from '@/lib/api';

// This wrapper ensures AuthProvider is applied
export default function AdminDashboardPageWrapper() {
  return (
    <AuthProvider>
      <AdminDashboardPage />
    </AuthProvider>
  );
}

function AdminDashboardPage() {
  const router = useRouter();
  const { user, isAuthenticated, isAdmin } = useAuth(); // ✅ Now safe

  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);

  // Redirect if not logged in or not admin
  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
    } else if (!isAdmin) {
      router.push('/'); 
    }
  }, [isAuthenticated, isAdmin, router]);

  // Fetch admin data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const toursData = await fetchTours();
        setTours(toursData);
      } catch (error) {
        console.error('Error fetching admin data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (isAuthenticated && isAdmin) {
      fetchData();
    }
  }, [isAuthenticated, isAdmin]);

  if (!isAuthenticated || !isAdmin || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
        Loading admin dashboard...
      </div>
    );
  }

  return (
    <DashboardContent
      tours={<ToursContent tours={tours} />}
      settings={<SettingsContent />}
    />
  );
}








