'use client';

import { Form, Input, Button, Typography, Card, Divider, Checkbox, message } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

const { Title, Text } = Typography;

export default function SignUp() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  const onFinish = async (values: any) => {
    setLoading(true);

    try {
      const response = await axios.post(`${API_URL}/auth/register`, {
        username: values.username,
        password: values.password,
      });

      message.success(response.data.message || 'Admin registered successfully!');

      setTimeout(() => {
        router.push('/signin');
      }, 800);
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message || 'Registration failed. Please try again.';
      message.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundImage: "url('/sign-background.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px',
        position: 'relative',
      }}
    >
      {/* Dark overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'rgba(0,0,0,0.45)',
          zIndex: 1,
        }}
      />

      <Card
        style={{
          width: 550,
          borderRadius: '18px',
          boxShadow: '0 10px 50px rgba(0,0,0,0.4)',
          background: 'rgba(255,255,255,0.18)',
          border: '1px solid rgba(255,255,255,0.3)',
          backdropFilter: 'blur(12px)',
          zIndex: 2,
          position: 'relative',
        }}
      >
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <Title level={2} style={{ marginBottom: '8px', color: '#ffffff' }}>
            Create Admin Account 🌿
          </Title>
          <Text style={{ color: 'rgba(255,255,255,0.85)' }}>
            Register as an Admin to manage tourism packages
          </Text>
        </div>

        <Form
          form={form}
          name="signup"
          onFinish={onFinish}
          size="large"
          layout="vertical"
          scrollToFirstError
        >
          <Form.Item
            name="username"
            label={<span style={{ color: '#fff' }}>Username</span>}
            rules={[
              { required: true, message: 'Please enter username' },
              { min: 3, message: 'Username must be at least 3 characters' },
            ]}
          >
            <Input
              prefix={<UserOutlined />}
              placeholder="admin"
              style={{ borderRadius: '12px', padding: '10px' }}
            />
          </Form.Item>

          <Form.Item
            name="password"
            label={<span style={{ color: '#fff' }}>Password</span>}
            rules={[
              { required: true, message: 'Please enter password' },
              { min: 6, message: 'Password must be at least 6 characters' },
            ]}
            hasFeedback
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="Create a strong password"
              style={{ borderRadius: '12px', padding: '10px' }}
            />
          </Form.Item>

          <Form.Item
            name="confirmPassword"
            label={<span style={{ color: '#fff' }}>Confirm Password</span>}
            dependencies={['password']}
            rules={[
              { required: true, message: 'Please confirm your password' },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('Passwords do not match'));
                },
              }),
            ]}
            hasFeedback
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="Confirm your password"
              style={{ borderRadius: '12px', padding: '10px' }}
            />
          </Form.Item>

          <Form.Item
            name="agreement"
            valuePropName="checked"
            rules={[
              {
                validator: (_, value) =>
                  value
                    ? Promise.resolve()
                    : Promise.reject(new Error('Please accept the terms and conditions')),
              },
            ]}
          >
            <Checkbox style={{ color: '#fff' }}>
              I agree to the{' '}
              <Link href="/terms" style={{ color: '#00ff99', fontWeight: 600 }}>
                Terms and Conditions
              </Link>{' '}
              and{' '}
              <Link href="/privacy" style={{ color: '#00ff99', fontWeight: 600 }}>
                Privacy Policy
              </Link>
            </Checkbox>
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              block
              loading={loading}
              size="large"
              style={{
                borderRadius: '12px',
                background: 'linear-gradient(90deg, #00c853, #00e676)',
                border: 'none',
                fontWeight: 700,
                height: '48px',
              }}
            >
              Register Admin
            </Button>
          </Form.Item>

          <Divider
            plain
            style={{
              color: '#fff',
              borderColor: 'rgba(255,255,255,0.3)',
            }}
          >
            Already registered?
          </Divider>

          <div style={{ textAlign: 'center' }}>
            <Text style={{ color: 'rgba(255,255,255,0.9)' }}>
              Already have an account?{' '}
            </Text>

            <Link
              href="/signin"
              style={{
                color: '#00ff99',
                fontWeight: 800,
              }}
            >
              Sign in
            </Link>
          </div>
        </Form>
      </Card>
    </div>
  );
}




