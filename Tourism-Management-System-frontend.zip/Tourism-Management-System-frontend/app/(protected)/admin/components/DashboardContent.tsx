"use client";

import React from "react";
import {
  Layout,
  Menu,
  Card,
  Row,
  Col,
  Avatar,
  Typography,
  Button,
} from "antd";
import {
  DashboardOutlined,
  CalendarOutlined,
  AppstoreOutlined,
  HomeOutlined,
  SettingOutlined,
} from "@ant-design/icons";

const { Header, Sider, Content } = Layout;
const { Title, Text } = Typography;

export default function AdminDashboard() {
  return (
    <Layout style={{ minHeight: "100vh" }}>
      {/* ============ SIDEBAR ============ */}
      <Sider
        width={250}
        style={{
          background: "#1b5e20",
          position: "fixed",
          height: "100vh",
          left: 0,
        }}
      >
        {/* Logo */}
        <div
          style={{
            height: 70,
            display: "flex",
            alignItems: "center",
            paddingLeft: 20,
            color: "white",
            fontSize: 20,
            fontWeight: 700,
            background: "#2e7d32",
          }}
        >
          🌍 TourManager
        </div>

        {/* Menu */}
        <Menu
          mode="inline"
          defaultSelectedKeys={["1"]}
          style={{
            background: "transparent",
            color: "white",
            borderRight: "none",
            marginTop: 10,
          }}
          items={[
            {
              key: "1",
              icon: <DashboardOutlined />,
              label: "Dashboard",
            },
            {
              key: "2",
              icon: <CalendarOutlined />,
              label: "Bookings",
            },
            {
              key: "3",
              icon: <AppstoreOutlined />,
              label: "Packages",
            },
            {
              key: "4",
              icon: <HomeOutlined />,
              label: "Hotels",
            },
            {
              key: "5",
              icon: <SettingOutlined />,
              label: "Settings",
            },
          ]}
        />

        {/* Bottom Admin Info */}
        <div
          style={{
            position: "absolute",
            bottom: 20,
            left: 20,
            right: 20,
            background: "#2e7d32",
            borderRadius: 10,
            padding: 12,
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Avatar style={{ background: "#66bb6a" }}>A</Avatar>
          <div>
            <Text style={{ color: "white", fontWeight: 600 }}>
              Admin User
            </Text>
            <br />
            <Text style={{ color: "#c8e6c9", fontSize: 12 }}>
              Administrator
            </Text>
          </div>
        </div>
      </Sider>

      {/* ============ MAIN LAYOUT ============ */}
      <Layout style={{ marginLeft: 250 }}>
        {/* Header */}
        <Header
          style={{
            background: "#ffffff",
            padding: "0 20px",
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
          }}
        >
          <Avatar style={{ background: "#66bb6a" }}>A</Avatar>
        </Header>

        {/* Content */}
        <Content style={{ padding: 24, background: "#f0f2f5" }}>
          {/* Welcome Banner */}
          <Card
            style={{
              marginBottom: 24,
              borderRadius: 20,
              background:
                "linear-gradient(135deg, #66bb6a 0%, #43a047 100%)",
              color: "white",
              border: "none",
            }}
          >
            <Title level={2} style={{ color: "white" }}>
              Welcome back, Admin! 👋
            </Title>
            <Text style={{ color: "rgba(255,255,255,0.9)" }}>
              Here's what's happening with your tourism management system today.
            </Text>
          </Card>

          {/* Quick Access */}
          <Card title="🚀 Quick Access" style={{ marginBottom: 24 }}>
            <Row gutter={16}>
              <Col span={6}>
                <Card hoverable>
                  🌍 <b>Package Management</b>
                  <p>Manage all tour packages</p>
                </Card>
              </Col>
              <Col span={6}>
                <Card hoverable>
                  🏨 <b>Hotels</b>
                  <p>Manage hotel details</p>
                </Card>
              </Col>
              <Col span={6}>
                <Card hoverable>
                  📌 <b>Bookings</b>
                  <p>Manage customer bookings</p>
                </Card>
              </Col>
              <Col span={6}>
                <Card hoverable>
                  💰 <b>Payments</b>
                  <p>Track revenue and payments</p>
                </Card>
              </Col>
            </Row>
          </Card>

          {/* Bottom Section */}
          <Row gutter={16}>
            <Col span={12}>
              <Card title="🏆 Top Packages" style={{ height: 300 }}>
                No data
              </Card>
            </Col>

            <Col span={12}>
              <Card title="📋 Recent Activities" style={{ height: 300 }}>
                No data
              </Card>
            </Col>
          </Row>
        </Content>
      </Layout>
    </Layout>
  );
}





