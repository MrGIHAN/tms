"use client";

import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Space,
  Card,
  Tooltip,
  message,
  Tag,
} from "antd";
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  SearchOutlined,
  EnvironmentOutlined,
  PhoneOutlined,
  MailOutlined,
  PictureOutlined,
} from "@ant-design/icons";
import { fetchHotels, createHotel, updateHotel, deleteHotel } from "@/lib/api";

export interface Hotel {
  _id?: string;
  name: string;
  location: string;
  description?: string;
  contactNumber?: string;
  email?: string;
  images: string[];
}

export default function HotelContent() {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [filteredHotels, setFilteredHotels] = useState<Hotel[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentHotel, setCurrentHotel] = useState<Hotel | null>(null);
  const [searchText, setSearchText] = useState("");

  const [form] = Form.useForm();

  const fetchAllHotels = async () => {
    try {
      const data = await fetchHotels();
      setHotels(data);
      setFilteredHotels(data);
    } catch (error) {
      console.error(error);
      message.error("Failed to fetch hotels!");
    }
  };

  useEffect(() => {
    fetchAllHotels();
  }, []);

  const handleSearch = (value: string) => {
    setSearchText(value);
    const filtered = hotels.filter(
      (hotel) =>
        hotel.name.toLowerCase().includes(value.toLowerCase()) ||
        hotel.location.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredHotels(filtered);
  };

  const showModal = () => {
    setIsEditMode(false);
    setCurrentHotel(null);
    form.resetFields();
    setIsModalOpen(true);
  };

  const handleEdit = (hotel: Hotel) => {
    setIsEditMode(true);
    setCurrentHotel(hotel);
    form.setFieldsValue({
      ...hotel,
      images: hotel.images?.join("\n") || "",
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id?: string) => {
    if (!id) return;
    Modal.confirm({
      title: "Are you sure you want to delete this hotel?",
      okText: "Yes",
      okType: "danger",
      cancelText: "Cancel",
      onOk: async () => {
        try {
          await deleteHotel(id);
          message.success("Hotel deleted successfully!");
          fetchAllHotels();
        } catch (error) {
          console.error(error);
          message.error("Failed to delete hotel!");
        }
      },
    });
  };

  const handleOk = async () => {
    try {
      const values = await form.validateFields();

      const imagesArray = values.images
        ?.split("\n")
        .map((img: string) => img.trim())
        .filter((img: string) => img !== "") || [];

      const payload: Hotel = {
        name: values.name,
        location: values.location,
        description: values.description,
        contactNumber: values.contactNumber,
        email: values.email,
        images: imagesArray,
      };

      if (isEditMode && currentHotel?._id) {
        await updateHotel(currentHotel._id, payload);
        message.success("Hotel updated successfully!");
      } else {
        await createHotel(payload);
        message.success("Hotel added successfully!");
      }

      setIsModalOpen(false);
      form.resetFields();
      fetchAllHotels();
    } catch (error) {
      console.error(error);
      message.error("Failed to save hotel!");
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    form.resetFields();
  };

  const columns = [
    {
      title: "Hotel Name",
      dataIndex: "name",
      key: "name",
      render: (text: string) => <strong style={{ color: "#2e7d32" }}>{text}</strong>,
    },
    {
      title: "Location",
      dataIndex: "location",
      key: "location",
      render: (text: string) => (
        <Space>
          <EnvironmentOutlined style={{ color: "#1890ff" }} />
          {text}
        </Space>
      ),
    },
    {
      title: "Contact",
      key: "contact",
      render: (_: any, record: Hotel) => (
        <div>
          <div>
            <PhoneOutlined style={{ color: "#26a69a" }} /> {record.contactNumber || "N/A"}
          </div>
          <div>
            <MailOutlined style={{ color: "#ff9800" }} /> {record.email || "N/A"}
          </div>
        </div>
      ),
    },
    {
      title: "Images",
      dataIndex: "images",
      key: "images",
      render: (images: string[]) => (
        <Tag color="green">
          <PictureOutlined /> {images?.length || 0} Images
        </Tag>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: Hotel) => (
        <Space>
          <Tooltip title="Edit">
            <Button type="primary" ghost icon={<EditOutlined />} onClick={() => handleEdit(record)} />
          </Tooltip>
          <Tooltip title="Delete">
            <Button danger icon={<DeleteOutlined />} onClick={() => handleDelete(record._id)} />
          </Tooltip>
        </Space>
      ),
    },
  ];

  return (
    <div style={{ padding: 24, background: "#f0f2f5", minHeight: "100vh" }}>
      <Card
        title={<strong style={{ fontSize: 18, color: "#2e7d32" }}>🏨 Hotel Management</strong>}
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={showModal}>Add Hotel</Button>}
        style={{ borderRadius: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.08)" }}
      >
        <Input
          placeholder="Search hotels by name or location..."
          prefix={<SearchOutlined />}
          value={searchText}
          onChange={(e) => handleSearch(e.target.value)}
          style={{ marginBottom: 16, maxWidth: 350 }}
          allowClear
        />
        <Table columns={columns} dataSource={filteredHotels} rowKey="_id" pagination={{ pageSize: 6 }} />
      </Card>

      <Modal
        title={isEditMode ? "Edit Hotel" : "Add Hotel"}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        okText={isEditMode ? "Update" : "Add"}
        width={700}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="Hotel Name" rules={[{ required: true }]}>
            <Input placeholder="Enter hotel name" />
          </Form.Item>
          <Form.Item name="location" label="Location" rules={[{ required: true }]}>
            <Input placeholder="Enter hotel location" />
          </Form.Item>
          <Form.Item name="description" label="Description">
            <Input.TextArea rows={3} placeholder="Enter description" />
          </Form.Item>
          <Form.Item name="contactNumber" label="Contact Number">
            <Input placeholder="Enter contact number" />
          </Form.Item>
          <Form.Item name="email" label="Email">
            <Input placeholder="Enter email" />
          </Form.Item>
          <Form.Item name="images" label="Hotel Images (one per line)">
            <Input.TextArea rows={6} placeholder="Enter image URLs, one per line" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}

