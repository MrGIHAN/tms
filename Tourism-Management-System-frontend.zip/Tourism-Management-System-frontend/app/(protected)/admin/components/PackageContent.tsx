"use client";

import React, { useState, useEffect } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  message,
} from "antd";
import { PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined } from "@ant-design/icons";
import axios from "axios";

const { Option } = Select;

interface Photo {
  location?: string;
  photoUrl: string;
  isThumbnail?: boolean;
}

interface Package {
  _id?: string;
  packageName: string;
  description?: string;
  maximumPassenger: number;
  contactNumber?: string;
  email?: string;
  photoGallery: Photo[];
  location: string[];
  price: number;
  vehicleType?: string;
  vehicleCount?: number;
}

export default function Packages() {
  const [packages, setPackages] = useState<Package[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<Package[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentPackage, setCurrentPackage] = useState<Package | null>(null);
  const [form] = Form.useForm();
  const [searchText, setSearchText] = useState("");

  const API_URL = "http://localhost:5000/api/packages"; // replace with your backend URL

  // Fetch packages
  const fetchPackages = async () => {
    try {
      const res = await axios.get(API_URL);
      setPackages(res.data);
      setFilteredPackages(res.data);
    } catch (error) {
      console.error(error);
      message.error("Failed to fetch packages from server!");
    }
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  // Search
  const handleSearch = (value: string) => {
    setSearchText(value);
    const filtered = packages.filter(
      (pkg) =>
        pkg.packageName.toLowerCase().includes(value.toLowerCase()) ||
        pkg.location.join(",").toLowerCase().includes(value.toLowerCase())
    );
    setFilteredPackages(filtered);
  };

  // Show modal
  const showModal = () => {
    setIsEditMode(false);
    setCurrentPackage(null);
    form.resetFields();
    setIsModalOpen(true);
  };

  // Edit package
  const handleEdit = (pkg: Package) => {
    setIsEditMode(true);
    setCurrentPackage(pkg);
    form.setFieldsValue({
      ...pkg,
      location: pkg.location.join(", "),
      photoGallery: pkg.photoGallery || [],
    });
    setIsModalOpen(true);
  };

  // Delete package
  const handleDelete = (id: string) => {
    Modal.confirm({
      title: "Are you sure you want to delete this package?",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "Cancel",
      onOk: async () => {
        try {
          await axios.delete(`${API_URL}/${id}`);
          message.success("Package deleted!");
          fetchPackages();
        } catch (error) {
          console.error(error);
          message.error("Failed to delete package!");
        }
      },
    });
  };

  // Save package (Add/Edit)
  const handleOk = async () => {
    try {
      const values = await form.validateFields();

      // Convert location string to array
      const locationsArray = values.location
        ? values.location.split(",").map((loc: string) => loc.trim())
        : [];

      const payload: Package = {
        ...values,
        location: locationsArray,
        photoGallery: values.photoGallery || [],
      };

      if (isEditMode && currentPackage?._id) {
        await axios.put(`${API_URL}/${currentPackage._id}`, payload);
        message.success("Package updated!");
      } else {
        await axios.post(API_URL, payload);
        message.success("Package added!");
      }
      setIsModalOpen(false);
      form.resetFields();
      fetchPackages();
    } catch (error) {
      console.error(error);
      message.error("Failed to save package!");
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    form.resetFields();
  };

  // Table columns
  const columns = [
    { title: "Name", dataIndex: "packageName", key: "packageName" },
    { title: "Locations", dataIndex: "location", key: "location", render: (loc: string[]) => loc.join(", ") },
    { title: "Price", dataIndex: "price", key: "price", render: (price: number) => `$${price}` },
    { title: "Capacity", dataIndex: "maximumPassenger", key: "maximumPassenger" },
    {
      title: "Actions",
      key: "actions",
      render: (_: any, record: Package) => (
        <Space>
          <Button icon={<EditOutlined />} onClick={() => handleEdit(record)} />
          <Button danger icon={<DeleteOutlined />} onClick={() => handleDelete(record._id!)} />
        </Space>
      ),
    },
  ];

  return (
    <div style={{ padding: 24 }}>
      <Space style={{ marginBottom: 16 }}>
        <Input
          placeholder="Search packages..."
          prefix={<SearchOutlined />}
          value={searchText}
          onChange={(e) => handleSearch(e.target.value)}
          allowClear
        />
        <Button type="primary" icon={<PlusOutlined />} onClick={showModal}>
          Add Package
        </Button>
      </Space>

      <Table columns={columns} dataSource={filteredPackages} rowKey="_id" />

      <Modal
        title={isEditMode ? "Edit Package" : "Add Package"}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        width={800}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="packageName" label="Package Name" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="description" label="Description">
            <Input.TextArea rows={3} />
          </Form.Item>
          <Form.Item name="maximumPassenger" label="Maximum Passenger" rules={[{ required: true }]}>
            <InputNumber min={1} style={{ width: "100%" }} />
          </Form.Item>
          <Form.Item name="location" label="Locations (comma separated)">
            <Input placeholder="City1, City2" />
          </Form.Item>
          <Form.Item name="price" label="Price" rules={[{ required: true }]}>
            <InputNumber min={0} style={{ width: "100%" }} />
          </Form.Item>
          <Form.List name="photoGallery">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Space key={key} style={{ display: "flex", marginBottom: 8 }} align="baseline">
                    <Form.Item {...restField} name={[name, "photoUrl"]} rules={[{ required: true }]}>
                      <Input placeholder="Photo URL" />
                    </Form.Item>
                    <Form.Item {...restField} name={[name, "location"]}>
                      <Input placeholder="Location (optional)" />
                    </Form.Item>
                    <Form.Item {...restField} name={[name, "isThumbnail"]} valuePropName="checked">
                      <Input type="checkbox" /> Thumbnail
                    </Form.Item>
                    <Button danger onClick={() => remove(name)}>
                      Delete
                    </Button>
                  </Space>
                ))}
                {fields.length < 10 && (
                  <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                    Add Photo
                  </Button>
                )}
              </>
            )}
          </Form.List>
        </Form>
      </Modal>
    </div>
  );
}

