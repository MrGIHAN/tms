"use client";

import React from "react";
import { Card, Row, Col, Form, Input, Button, Switch, Select, Divider } from "antd";
import { UserOutlined, MailOutlined, LockOutlined, BellOutlined, GlobalOutlined, SaveOutlined } from "@ant-design/icons";

const { Option } = Select;

export default function SettingsContent() {
  return (
    <div style={{ padding: 24, minHeight: "100vh", background: "#f1f8e9" }}>
      {/* Header */}
      <Card style={{ borderRadius: 16, background: "#66bb6a", marginBottom: 24, border: "none" }} bodyStyle={{ padding: 24 }}>
        <h1 style={{ color: "white", fontSize: 28, margin: 0 }}>⚙️ Settings</h1>
        <p style={{ color: "rgba(255,255,255,0.9)", marginTop: 4 }}>Manage your account and preferences</p>
      </Card>

      <Row gutter={16}>
        {/* Profile Settings */}
        <Col xs={24} lg={12}>
          <Card title="Profile Settings" style={{ borderRadius: 16 }}>
            <Form layout="vertical">
              <Form.Item label="Full Name" name="name">
                <Input prefix={<UserOutlined />} placeholder="Admin User" size="large" />
              </Form.Item>
              <Form.Item label="Email" name="email">
                <Input prefix={<MailOutlined />} placeholder="admin@tour.com" size="large" />
              </Form.Item>
              <Form.Item label="Phone" name="phone">
                <Input placeholder="+1 234 567 8900" size="large" />
              </Form.Item>
              <Button type="primary" icon={<SaveOutlined />} size="large" block style={{ background: "#43a047" }}>Save Profile</Button>
            </Form>
          </Card>
        </Col>

        {/* Security Settings */}
        <Col xs={24} lg={12}>
          <Card title="Security Settings" style={{ borderRadius: 16 }}>
            <Form layout="vertical">
              <Form.Item label="Current Password" name="currentPassword">
                <Input.Password prefix={<LockOutlined />} placeholder="Current password" size="large" />
              </Form.Item>
              <Form.Item label="New Password" name="newPassword">
                <Input.Password prefix={<LockOutlined />} placeholder="New password" size="large" />
              </Form.Item>
              <Form.Item label="Confirm Password" name="confirmPassword">
                <Input.Password prefix={<LockOutlined />} placeholder="Confirm password" size="large" />
              </Form.Item>
              <Button danger icon={<SaveOutlined />} size="large" block>Change Password</Button>
            </Form>
          </Card>
        </Col>

        {/* Notifications */}
        <Col xs={24} lg={12}>
          <Card title="Notifications" style={{ borderRadius: 16 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {["Email Notifications", "SMS Notifications", "Push Notifications", "Marketing Emails"].map((n, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between" }}>
                  <div>{n}</div>
                  <Switch defaultChecked={i % 2 === 0} />
                </div>
              ))}
            </div>
          </Card>
        </Col>

        {/* Preferences */}
        <Col xs={24} lg={12}>
          <Card title="Preferences" style={{ borderRadius: 16 }}>
            <Form layout="vertical">
              <Form.Item label="Language" name="language">
                <Select size="large" defaultValue="en">
                  <Option value="en">English</Option>
                  <Option value="es">Spanish</Option>
                  <Option value="fr">French</Option>
                </Select>
              </Form.Item>
              <Form.Item label="Currency" name="currency">
                <Select size="large" defaultValue="usd">
                  <Option value="usd">USD</Option>
                  <Option value="eur">EUR</Option>
                  <Option value="gbp">GBP</Option>
                </Select>
              </Form.Item>
              <Form.Item label="Timezone" name="timezone">
                <Select size="large" defaultValue="utc">
                  <Option value="utc">UTC</Option>
                  <Option value="est">EST</Option>
                </Select>
              </Form.Item>
              <Button type="primary" icon={<SaveOutlined />} size="large" block style={{ background: "#ffa726" }}>Save Preferences</Button>
            </Form>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
