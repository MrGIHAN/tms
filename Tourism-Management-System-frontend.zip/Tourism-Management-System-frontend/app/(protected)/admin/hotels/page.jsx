"use client";

import HotelContent from "../components/HotelContent";

export default function HotelsPage() {
  return <HotelContent />;
}


