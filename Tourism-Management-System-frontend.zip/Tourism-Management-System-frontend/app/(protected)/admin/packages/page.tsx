"use client";

import ToursContent from "../components/PackageContent";

export default function ToursPage() {
  return <ToursContent />;
}