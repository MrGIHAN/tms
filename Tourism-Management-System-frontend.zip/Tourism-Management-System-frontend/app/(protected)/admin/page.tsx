"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";

// Import admin components with absolute paths
import DashboardContent from "@/app/(protected)/admin/components/DashboardContent";
import SettingsContent from "@/app/(protected)/admin/components/SettingsContent";
import PackageContent from "@/app/(protected)/admin/components/PackageContent";

import { fetchTours } from "@/lib/api"; // Only existing API functions

export default function AdminDashboardPage() {
  const router = useRouter();
  const { user, isAuthenticated, isAdmin } = useAuth();

  const [tours, setTours] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login"); // redirect to login
    } else if (!isAdmin) {
      router.push("/"); // redirect non-admins to homepage
    }
  }, [isAuthenticated, isAdmin, router]);

  // Fetch tours for admin dashboard
  useEffect(() => {
    const fetchData = async () => {
      try {
        const toursData = await fetchTours();
        setTours(toursData);
      } catch (error) {
        console.error("Error fetching admin tours:", error);
      } finally {
        setLoading(false);
      }
    };

    if (isAuthenticated && isAdmin) {
      fetchData();
    }
  }, [isAuthenticated, isAdmin]);

  // Show loading screen if fetching data
  if (!isAuthenticated || !isAdmin || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
        Loading admin dashboard...
      </div>
    );
  }

  return (
    <DashboardContent
      tours={<PackageContent tours={tours} />}
      settings={<SettingsContent />}
    />
  );
}



