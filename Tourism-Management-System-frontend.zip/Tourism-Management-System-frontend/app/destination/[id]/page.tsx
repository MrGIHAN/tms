"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { 
  ArrowLeft, 
  MapPin, 
  Star,
  Camera,
  Info,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

export default function DestinationDetailPage() {
  const params = useParams();
  const [destination, setDestination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    fetchDestinationDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  const fetchDestinationDetails = async () => {
    try {
      const res = await fetch(`${API_URL}/destinations/${params.id}`);
      if (res.ok) {
        const data = await res.json();
        setDestination(data);
      }
    } catch (error) {
      console.error('Error fetching destination:', error);
      // Fallback demo data
      setDestination({
        _id: params.id,
        name: 'Sigiriya Rock Fortress',
        location: 'Central Province',
        description: 'Sigiriya or Sinhagiri is an ancient rock fortress located in the northern Matale District near the town of Dambulla in the Central Province, Sri Lanka. It is a site of historical and archaeological significance that is dominated by a massive column of rock approximately 180 meters high.',
        image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80',
          'https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?w=1200&q=80',
          'https://images.unsplash.com/photo-1553500873-d7b24ec0c7f9?w=1200&q=80'
        ],
        rating: 4.8,
        category: 'Historical Site'
      });
    } finally {
      setLoading(false);
    }
  };

  const nextImage = () => {
    if (!destination) return;
    const images = destination.images || [destination.image];
    setSelectedImage((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const prevImage = () => {
    if (!destination) return;
    const images = destination.images || [destination.image];
    setSelectedImage((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading destination...</p>
      </div>
    );
  }

  if (!destination) {
    return (
      <div className="not-found">
        <h1>Destination Not Found</h1>
        <Link href="/destinations">
          <button className="back-btn">Back to Destinations</button>
        </Link>
      </div>
    );
  }

  const images = destination.images || [destination.image];

  return (
    <div className="destination-detail-page">
      {/* Header */}
      <header className="detail-header">
        <div className="container">
          <Link href="/destinations">
            <button className="back-button">
              <ArrowLeft size={20} />
              <span>Back to Destinations</span>
            </button>
          </Link>
        </div>
      </header>

      {/* Hero Gallery */}
      <section className="hero-gallery">
        <div className="main-image">
          <img src={images[selectedImage]} alt={destination.name} />
          {images.length > 1 && (
            <>
              <div className="gallery-controls">
                <button onClick={prevImage} className="gallery-btn" aria-label="Previous image">
                  <ChevronLeft size={24} />
                </button>
                <button onClick={nextImage} className="gallery-btn" aria-label="Next image">
                  <ChevronRight size={24} />
                </button>
              </div>
              <div className="image-counter">
                {selectedImage + 1} / {images.length}
              </div>
            </>
          )}
        </div>

        {images.length > 1 && (
          <div className="thumbnail-gallery">
            {images.map((img, index) => (
              <div
                key={index}
                className={`thumbnail ${selectedImage === index ? 'active' : ''}`}
                onClick={() => setSelectedImage(index)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    setSelectedImage(index);
                  }
                }}
                aria-label={`View image ${index + 1}`}
              >
                <img src={img} alt={`View ${index + 1}`} />
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Content */}
      <div className="container">
        <div className="content-wrapper">
          <div className="main-content">
            <div className="destination-header">
              <div>
                <h1 className="destination-title">{destination.name}</h1>
                <div className="location-info">
                  <MapPin size={18} />
                  <span>{destination.location}</span>
                </div>
              </div>
              {destination.rating && (
                <div className="rating-badge">
                  <Star size={20} fill="#FFB800" color="#FFB800" />
                  <span>{destination.rating}</span>
                </div>
              )}
            </div>

            {destination.category && (
              <div className="category-badge">{destination.category}</div>
            )}

            {destination.description && (
              <div className="description-section">
                <h2>About {destination.name}</h2>
                <p>{destination.description}</p>
              </div>
            )}

            {destination.highlights && destination.highlights.length > 0 && (
              <div className="highlights-section">
                <h2>Highlights</h2>
                <ul className="highlights-list">
                  {destination.highlights.map((highlight, index) => (
                    <li key={index}>
                      <Camera size={18} />
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {destination.tips && (
              <div className="tips-section">
                <h2>
                  <Info size={24} />
                  Visitor Tips
                </h2>
                <p>{destination.tips}</p>
              </div>
            )}
          </div>

          <div className="sidebar">
            <div className="info-card">
              <h3>Plan Your Visit</h3>
              
              {destination.bestTime && (
                <div className="info-item">
                  <strong>Best Time to Visit:</strong>
                  <p>{destination.bestTime}</p>
                </div>
              )}

              {destination.duration && (
                <div className="info-item">
                  <strong>Recommended Duration:</strong>
                  <p>{destination.duration}</p>
                </div>
              )}

              {destination.entryFee && (
                <div className="info-item">
                  <strong>Entry Fee:</strong>
                  <p>{destination.entryFee}</p>
                </div>
              )}

              <Link href="/packages">
                <button className="explore-packages-btn">
                  Explore Tour Packages
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .destination-detail-page {
          min-height: 100vh;
          background: #f8f9fa;
        }

        .detail-header {
          background: white;
          padding: 20px 0;
          border-bottom: 1px solid #e0e0e0;
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .back-button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          background: transparent;
          border: 1px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.3s;
          font-family: inherit;
          font-size: 14px;
          color: inherit;
        }

        .back-button:hover {
          background: #f5f5f5;
        }

        .hero-gallery {
          background: #000;
        }

        .main-image {
          position: relative;
          height: 600px;
          overflow: hidden;
        }

        .main-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .gallery-controls {
          position: absolute;
          top: 50%;
          left: 0;
          right: 0;
          transform: translateY(-50%);
          display: flex;
          justify-content: space-between;
          padding: 0 20px;
          pointer-events: none;
        }

        .gallery-btn {
          width: 50px;
          height: 50px;
          background: rgba(255, 255, 255, 0.9);
          border: none;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
          pointer-events: auto;
        }

        .gallery-btn:hover {
          background: white;
          transform: scale(1.1);
        }

        .image-counter {
          position: absolute;
          bottom: 20px;
          right: 20px;
          padding: 8px 16px;
          background: rgba(0, 0, 0, 0.7);
          color: white;
          border-radius: 20px;
          font-size: 14px;
        }

        .thumbnail-gallery {
          display: flex;
          gap: 12px;
          padding: 20px;
          overflow-x: auto;
        }

        .thumbnail {
          width: 120px;
          height: 80px;
          flex-shrink: 0;
          border-radius: 8px;
          overflow: hidden;
          cursor: pointer;
          border: 3px solid transparent;
          opacity: 0.6;
          transition: all 0.3s;
        }

        .thumbnail.active {
          border-color: #7ec850;
          opacity: 1;
        }

        .thumbnail:hover {
          opacity: 1;
        }

        .thumbnail img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 0 40px;
        }

        .content-wrapper {
          display: grid;
          grid-template-columns: 1fr 400px;
          gap: 40px;
          padding: 60px 0;
        }

        .destination-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 24px;
        }

        .destination-title {
          font-size: 48px;
          font-weight: 700;
          color: #1a1a1a;
          margin-bottom: 12px;
          font-family: 'Playfair Display', serif;
        }

        .location-info {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #666;
          font-size: 18px;
        }

        .location-info :global(svg) {
          color: #7ec850;
        }

        .rating-badge {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 20px;
          background: white;
          border-radius: 50px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          font-size: 20px;
          font-weight: 700;
          color: #FFB800;
        }

        .category-badge {
          display: inline-block;
          padding: 10px 20px;
          background: #e8f5e9;
          color: #2d5016;
          border-radius: 20px;
          font-size: 14px;
          font-weight: 600;
          margin-bottom: 32px;
        }

        .description-section,
        .highlights-section,
        .tips-section {
          background: white;
          padding: 32px;
          border-radius: 16px;
          margin-bottom: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .description-section h2,
        .highlights-section h2,
        .tips-section h2 {
          font-size: 24px;
          font-weight: 600;
          color: #1a1a1a;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .description-section p,
        .tips-section p {
          font-size: 16px;
          line-height: 1.8;
          color: #555;
        }

        .highlights-list {
          list-style: none;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .highlights-list li {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 15px;
          color: #555;
        }

        .highlights-list :global(svg) {
          color: #7ec850;
          flex-shrink: 0;
        }

        .tips-section {
          background: #fff9e6;
          border-left: 4px solid #FFB800;
        }

        .sidebar {
          position: sticky;
          top: 100px;
          height: fit-content;
        }

        .info-card {
          background: white;
          padding: 32px;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .info-card h3 {
          font-size: 22px;
          font-weight: 600;
          color: #1a1a1a;
          margin-bottom: 24px;
        }

        .info-item {
          margin-bottom: 20px;
          padding-bottom: 20px;
          border-bottom: 1px solid #f0f0f0;
        }

        .info-item:last-of-type {
          border-bottom: none;
        }

        .info-item strong {
          display: block;
          font-size: 14px;
          color: #666;
          margin-bottom: 8px;
        }

        .info-item p {
          font-size: 16px;
          color: #1a1a1a;
          font-weight: 500;
          margin: 0;
        }

        .explore-packages-btn {
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #7ec850, #92d668);
          color: white;
          border: none;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.3s;
          margin-top: 24px;
        }

        .explore-packages-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(126, 200, 80, 0.4);
        }

        .loading-screen,
        .not-found {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 20px;
        }

        .spinner {
          width: 60px;
          height: 60px;
          border: 4px solid #f0f0f0;
          border-top: 4px solid #7ec850;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        .back-btn {
          padding: 12px 24px;
          background: #7ec850;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          cursor: pointer;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        @media (max-width: 1024px) {
          .content-wrapper {
            grid-template-columns: 1fr;
          }

          .sidebar {
            position: static;
          }
        }

        @media (max-width: 768px) {
          .destination-header {
            flex-direction: column;
            gap: 16px;
          }

          .destination-title {
            font-size: 36px;
          }

          .content-wrapper {
            padding: 40px 0;
          }
        }

        @media (max-width: 640px) {
          .destination-title {
            font-size: 32px;
          }

          .main-image {
            height: 400px;
          }

          .container {
            padding: 0 20px;
          }

          .description-section,
          .highlights-section,
          .tips-section,
          .info-card {
            padding: 24px;
          }

          .thumbnail {
            width: 100px;
            height: 70px;
          }
        }
      `}</style>
    </div>
  );
}