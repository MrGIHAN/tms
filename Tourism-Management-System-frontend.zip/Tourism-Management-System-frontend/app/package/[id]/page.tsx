'use client';

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  ShoppingCart,
  ChevronLeft,
  ChevronRight,
  Package,
  Clock,
  MapPin,
  Users
} from "lucide-react";

export default function PackageDetailPage() {
  const params = useParams();
  const router = useRouter();

  const [packageData, setPackageData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);

  const API_URL =
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

  const BASE_URL = API_URL.replace("/api", "");

  const resolveImage = (path) => {
    if (!path) return "/default-package.jpg";
    if (path.startsWith("http")) return path;
    return `${BASE_URL}${path}`;
  };

  useEffect(() => {
    if (!params?.id) return;

    const fetchPackage = async () => {
      try {
        const res = await fetch(`${API_URL}/packages/${params.id}`);
        if (!res.ok) {
          setPackageData(null);
          return;
        }
        const data = await res.json();
        setPackageData(data);
      } catch (error) {
        console.error("Fetch error:", error);
        setPackageData(null);
      } finally {
        setLoading(false);
      }
    };

    fetchPackage();
  }, [params?.id]);

  const addToCart = () => {
    if (!packageData) return;
    try {
      const cart = JSON.parse(localStorage.getItem("cart") || "[]");
      const existingIndex = cart.findIndex(item => item._id === packageData._id);
      if (existingIndex > -1) {
        cart[existingIndex].quantity = (cart[existingIndex].quantity || 1) + 1;
      } else {
        cart.push({
          _id: packageData._id,
          packageName: packageData.packageName,
          price: packageData.price,
          photoGallery: packageData.photoGallery,
          quantity: 1
        });
      }
      localStorage.setItem("cart", JSON.stringify(cart));
      router.push("/cart");
    } catch (err) {
      console.error("Cart error:", err);
    }
  };

  const nextImage = () => {
    if (!packageData?.photoGallery?.length) return;
    setSelectedImage(prev =>
      prev === packageData.photoGallery.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    if (!packageData?.photoGallery?.length) return;
    setSelectedImage(prev =>
      prev === 0 ? packageData.photoGallery.length - 1 : prev - 1
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364]">
        <div className="w-16 h-16 border-4 border-[rgba(255,255,255,0.2)] border-t-[#ff7e5f] rounded-full animate-spin mb-5" />
        <p className="text-white/80 text-lg font-medium">Loading package details...</p>
      </div>
    );
  }

  if (!packageData) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364] px-6">
        <Package size={64} color="#fff" className="mb-6" />
        <h1 className="text-4xl font-bold text-white mb-4">Package Not Found</h1>
        <p className="text-white/70 text-lg mb-8 text-center max-w-md">
          The package you&apos;re looking for doesn&apos;t exist or has been removed.
        </p>
        <Link href="/packages">
          <button className="px-8 py-3 bg-gradient-to-r from-[#ff7e5f] to-[#feb47b] text-[#0a0e0d] rounded-full font-semibold shadow-lg hover:scale-105 transition-all duration-300">
            Back to Packages
          </button>
        </Link>
      </div>
    );
  }

  const gallery = packageData.photoGallery || [];
  const currentImage =
    gallery.length > 0
      ? resolveImage(gallery[selectedImage]?.photoUrl)
      : "/default-package.jpg";

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364] text-white">
      {/* Header */}
      <header className="bg-transparent py-6 sticky top-0 z-50 backdrop-blur-xl">
        <div className="max-w-[1400px] mx-auto px-10">
          <Link href="/packages">
            <button className="flex items-center gap-3 px-6 py-3 bg-white/10 border border-white/20 rounded-full text-white text-sm font-medium transition-all duration-300 hover:bg-white/20 hover:border-white/40 hover:-translate-x-1">
              <ArrowLeft size={20} />
              <span>Back to Packages</span>
            </button>
          </Link>
        </div>
      </header>

      {/* Hero Gallery */}
      <section className="relative">
        <div className="relative h-[600px] overflow-hidden rounded-b-[50px] shadow-xl">
          <img
            src={currentImage}
            alt={packageData.packageName}
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
            onError={(e) => { e.target.src = "/default-package.jpg"; }}
          />

          {gallery.length > 1 && (
            <>
              <div className="absolute inset-0 flex items-center justify-between px-6">
                <button 
                  onClick={prevImage} 
                  className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-[#ff7e5f] to-[#feb47b]/80 rounded-full shadow-lg hover:scale-110 transition-all duration-300"
                  aria-label="Previous image"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={nextImage} 
                  className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-[#6a11cb] to-[#2575fc]/80 rounded-full shadow-lg hover:scale-110 transition-all duration-300"
                  aria-label="Next image"
                >
                  <ChevronRight size={24} />
                </button>
              </div>
              <div className="absolute bottom-6 right-6 px-4 py-2 bg-black/50 backdrop-blur-md rounded-full text-white text-sm font-medium border border-white/20">
                {selectedImage + 1} / {gallery.length}
              </div>
            </>
          )}
        </div>

        {/* Thumbnail Gallery */}
        {gallery.length > 1 && (
          <div className="bg-black/20 border-t border-white/10 py-4">
            <div className="max-w-[1400px] mx-auto px-10 flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
              {gallery.map((photo, index) => (
                <div
                  key={index}
                  className={`flex-shrink-0 w-32 h-24 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 border-2 ${
                    selectedImage === index
                      ? "border-[#ff7e5f] shadow-[0_0_20px_rgba(255,126,95,0.6)] scale-105"
                      : "border-white/10 hover:border-white/30"
                  }`}
                  onClick={() => setSelectedImage(index)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") setSelectedImage(index);
                  }}
                  aria-label={`View image ${index + 1}`}
                >
                  <img 
                    src={resolveImage(photo.photoUrl)} 
                    alt={`Gallery ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Content */}
      <div className="max-w-[1400px] mx-auto px-10 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gradient-to-r from-[#ff7e5f] via-[#feb47b] to-[#86fde8] mb-6 font-playfair leading-tight">
                {packageData.packageName}
              </h1>
            </div>

            {packageData.description && (
              <div className="bg-gradient-to-r from-[#ff7e5f]/20 via-[#feb47b]/10 to-[#86fde8]/20 border border-white/10 rounded-3xl p-8 backdrop-blur-sm shadow-lg">
                <h2 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                  <div className="w-1 h-8 bg-gradient-to-b from-[#ff7e5f] via-[#feb47b] to-[#86fde8] rounded-full" />
                  Package Overview
                </h2>
                <p className="text-white/90 text-lg leading-relaxed">
                  {packageData.description}
                </p>
              </div>
            )}

            {packageData.itinerary && packageData.itinerary.length > 0 && (
              <div className="space-y-6">
                {packageData.itinerary.map((item, index) => (
                  <div key={index} className="bg-gradient-to-r from-[#ff7e5f]/10 via-[#feb47b]/10 to-[#86fde8]/10 border border-white/10 rounded-2xl p-6 transition-all duration-300 hover:scale-105 hover:shadow-lg">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-[#ff7e5f] to-[#86fde8] rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-[#ff7e5f]/20 via-[#feb47b]/20 to-[#86fde8]/20 border border-white/20 rounded-full text-white text-sm font-semibold mb-3">
                          <MapPin size={14} />
                          {item.location}
                        </div>
                        <ul className="space-y-2 mt-3">
                          {item.activities.map((act, i) => (
                            <li key={i} className="flex items-start gap-3 text-white/90">
                              <span className="w-1.5 h-1.5 bg-[#ff7e5f] rounded-full mt-2 flex-shrink-0" />
                              <span>{act}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-32 space-y-6">
              <div className="bg-gradient-to-r from-[#ff7e5f]/20 via-[#feb47b]/20 to-[#86fde8]/20 border border-white/10 rounded-3xl p-8 backdrop-blur-sm shadow-lg">
                <div className="text-center pb-6 border-b border-white/10">
                  <div className="text-sm text-white/70 uppercase tracking-wider mb-2">
                    Price per person
                  </div>
                  <div className="flex items-baseline justify-center gap-2">
                    <span className="text-2xl text-white font-semibold">$</span>
                    <span className="text-5xl font-bold text-white font-poppins">
                      {packageData.price}
                    </span>
                  </div>
                </div>

                {packageData.duration && (
                  <div className="flex items-start gap-4 py-4 border-b border-white/10">
                    <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-[#ff7e5f]/30 to-[#86fde8]/30 rounded-xl flex-shrink-0">
                      <Clock size={20} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-white/60 uppercase tracking-wider mb-1">
                        Duration
                      </div>
                      <p className="text-white font-medium text-lg">{packageData.duration}</p>
                    </div>
                  </div>
                )}

                {packageData.location && packageData.location.length > 0 && (
                  <div className="flex items-start gap-4 py-4 border-b border-white/10">
                    <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-[#ff7e5f]/30 to-[#86fde8]/30 rounded-xl flex-shrink-0">
                      <MapPin size={20} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-white/60 uppercase tracking-wider mb-1">
                        Locations
                      </div>
                      <p className="text-white font-medium">{packageData.location.join(", ")}</p>
                    </div>
                  </div>
                )}

                {packageData.maximumPassenger && (
                  <div className="flex items-start gap-4 py-4 border-b border-white/10">
                    <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-r from-[#ff7e5f]/30 to-[#86fde8]/30 rounded-xl flex-shrink-0">
                      <Users size={20} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-white/60 uppercase tracking-wider mb-1">
                        Group Size
                      </div>
                      <p className="text-white font-medium text-lg">{packageData.maximumPassenger}</p>
                    </div>
                  </div>
                )}

                <button 
                  onClick={addToCart} 
                  className="w-full flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-br from-[#ff7e5f] to-[#86fde8] text-white rounded-full text-base font-bold tracking-wide transition-all duration-300 shadow-xl hover:-translate-y-1 hover:shadow-[0_8px_32px_rgba(255,126,95,0.6)] mt-6"
                >
                  <ShoppingCart size={20} /> 
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
