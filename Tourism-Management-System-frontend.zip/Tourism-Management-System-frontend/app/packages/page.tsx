'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import axios from 'axios';
import {
  StarIcon,
  CalendarIcon,
  UsersIcon,
  MapPinIcon,
  ArrowRightIcon,
} from '@heroicons/react/24/solid';

const ToursSection = () => {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/packages'); // your backend API endpoint
        setPackages(res.data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching packages:', err);
        setLoading(false);
      }
    };

    fetchPackages();
  }, []);

  return (
    <section className="tours-section py-32 relative overflow-hidden bg-gradient-to-b from-gray-900 via-green-900 to-gray-900">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-green-400 font-bold tracking-widest mb-2">
            CURATED JOURNEYS
          </span>
          <h2 className="text-4xl md:text-5xl font-extrabold text-white">
            Tour <span className="italic text-green-400">Packages</span>
          </h2>
          <p className="text-gray-300 mt-3">
            Handcrafted itineraries designed for the discerning traveler. Each journey promises authentic experiences and unforgettable memories.
          </p>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="loader mb-4 border-t-4 border-green-400 rounded-full w-12 h-12 animate-spin"></div>
            <p className="text-gray-300">Loading amazing packages...</p>
          </div>
        ) : (
          <>
            {/* Packages Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
              {packages.map((tour, index) => (
                <div
                  key={tour._id}
                  className="relative bg-gray-900 bg-opacity-20 border border-gray-700 rounded-3xl overflow-hidden backdrop-blur-sm transform hover:-translate-y-4 transition-all duration-500"
                >
                  {/* Featured Ribbon */}
                  {index === 0 && (
                    <div className="absolute top-4 -left-10 bg-gradient-to-tr from-yellow-400 to-yellow-300 px-10 py-1 rotate-[-45deg] shadow-lg z-10">
                      <span className="text-gray-900 text-xs font-bold tracking-wider">
                        ⭐ FEATURED
                      </span>
                    </div>
                  )}

                  {/* Image */}
                  <div className="relative h-72 overflow-hidden">
                    <img
                      src={tour.photoGallery?.[0]?.photoUrl || '/default-package.jpg'}
                      alt={tour.packageName}
                      className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                    />
                    <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-900 via-transparent" />
                    <div className="absolute top-4 right-4 px-4 py-1 bg-green-500 text-white rounded-full text-xs flex items-center gap-1 shadow">
                      <StarIcon className="w-3 h-3" /> BEST SELLER
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-xl md:text-2xl font-bold text-white">{tour.packageName}</h3>
                    <p className="text-gray-300 mt-1">{tour.description}</p>

                    {/* Meta */}
                    <div className="grid grid-cols-2 gap-3 mt-4 text-gray-300 text-sm">
                      <div className="flex items-center gap-1">
                        <CalendarIcon className="w-4 h-4" /> <span>{tour.duration || '5 Days'}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <UsersIcon className="w-4 h-4" /> <span>Max {tour.maximumPassenger || 12} people</span>
                      </div>
                    </div>

                    {/* Locations */}
                    <div className="flex flex-wrap gap-2 mt-4">
                      {tour.location?.map((loc, i) => (
                        <span
                          key={i}
                          className="text-xs text-green-400 bg-green-900 bg-opacity-30 px-3 py-1 rounded-full flex items-center gap-1"
                        >
                          <MapPinIcon className="w-3 h-3" /> {loc}
                        </span>
                      ))}
                    </div>

                    {/* Price and Button */}
                    <div className="flex items-center justify-between mt-6">
                      <div>
                        <p className="text-gray-400 text-xs uppercase">Starting from</p>
                        <p className="text-3xl font-extrabold text-white">
                          ${tour.price} <span className="text-gray-400 text-sm font-medium">/ person</span>
                        </p>
                      </div>
                      <Link href={`/package/${tour._id}`}>
                        <button className="flex items-center gap-2 bg-green-500 text-gray-900 font-bold px-5 py-3 rounded-full hover:scale-105 transition-transform">
                          Explore Tour <ArrowRightIcon className="w-4 h-4" />
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="grid md:grid-cols-4 gap-6 mt-16 bg-gray-900 bg-opacity-20 border border-gray-700 rounded-3xl p-8 text-center">
              <div>
                <p className="text-4xl font-bold text-green-400">{packages.length}+</p>
                <p className="text-gray-300 uppercase text-sm mt-1">Tour Packages</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-green-400">4.9★</p>
                <p className="text-gray-300 uppercase text-sm mt-1">Average Rating</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-green-400">500+</p>
                <p className="text-gray-300 uppercase text-sm mt-1">Happy Travelers</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-green-400">100%</p>
                <p className="text-gray-300 uppercase text-sm mt-1">Satisfaction</p>
              </div>
            </div>

            {/* View All */}
            <div className="text-center mt-12">
              <Link href="/packages">
                <button className="flex items-center gap-3 border border-green-500 text-green-400 px-8 py-3 rounded-full hover:bg-green-500 hover:text-gray-900 transition-all">
                  Explore All Packages <ArrowRightIcon className="w-5 h-5" />
                </button>
              </Link>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default ToursSection;




