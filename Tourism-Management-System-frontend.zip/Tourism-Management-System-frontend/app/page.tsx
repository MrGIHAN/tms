"use client";

import React, { useState, useEffect } from "react";
import { Search, MapPin, Calendar, Star, ArrowRight, Users, Globe, Shield, Heart, ChevronDown } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function HomePage() {
  const [scrollY, setScrollY] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [packages, setPackages] = useState([]);
  const [destinations, setDestinations] = useState([]);
  const [experiences, setExperiences] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    setIsVisible(true);
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    
    fetchAllData();
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchPackages(),
        fetchDestinations(),
        fetchExperiences()
      ]);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPackages = async () => {
    try {
      const res = await fetch(`${API_URL}/packages`);
      if (res.ok) {
        const data = await res.json();
        setPackages(data.slice(0, 6));
      } else {
        throw new Error('Failed to fetch');
      }
    } catch (error) {
      console.error('Error fetching packages:', error);
      setPackages([
        {
          _id: '1',
          title: "Heritage Trail",
          image: "https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?w=800&q=80",
          duration: "8 days • 7 nights",
          locations: ["SIGIRIYA", "TRADITIONAL SAFARI", "TEMPLE VISITS"],
          highlights: ["Ancient ruins", "Local cuisine", "Wildlife safari", "Traditional crafts"],
          price: 499,
          rating: 4.9,
          reviews: 124,
        },
        {
          _id: '2',
          title: "Coastal Paradise",
          image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80",
          duration: "6 days • 5 nights",
          locations: ["BEACHES", "WHALE WATCHING", "SURFING"],
          highlights: ["Beach resorts", "Water sports", "Seafood cuisine", "Sunset cruises"],
          price: 399,
          rating: 4.8,
          reviews: 98,
        },
        {
          _id: '3',
          title: "Tea Country Explorer",
          image: "https://images.unsplash.com/photo-1553500873-d7b24ec0c7f9?w=800&q=80",
          duration: "5 days • 4 nights",
          locations: ["ELLA", "NUWARA ELIYA", "TEA PLANTATIONS"],
          highlights: ["Train rides", "Tea tasting", "Hiking trails", "Mountain views"],
          price: 449,
          rating: 4.9,
          reviews: 156,
        },
      ]);
    }
  };

  const fetchDestinations = async () => {
    try {
      const res = await fetch(`${API_URL}/destinations`);
      if (res.ok) {
        const data = await res.json();
        setDestinations(data);
      } else {
        throw new Error('Failed to fetch destinations');
      }
    } catch (error) {
      console.error('Error fetching destinations:', error);
      setDestinations([
        { _id: '1', name: 'Nine Arch Bridge', image: 'https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?w=800&q=80', location: 'Ella' },
        { _id: '2', name: 'Sigiriya Rock', image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80', location: 'Dambulla' },
        { _id: '3', name: 'Galle Fort', image: 'https://images.unsplash.com/photo-1553500873-d7b24ec0c7f9?w=800&q=80', location: 'Galle' },
      ]);
    }
  };

  const fetchExperiences = async () => {
    try {
      const res = await fetch(`${API_URL}/experiences`);
      if (res.ok) {
        const data = await res.json();
        setExperiences(data.slice(0, 4));
      } else {
        throw new Error('Failed to fetch experiences');
      }
    } catch (error) {
      console.error('Error fetching experiences:', error);
      setExperiences([
        { _id: '1', title: 'Tea Plantation Tours', image: 'https://images.unsplash.com/photo-1564631191892-39a4a76b1f9b?w=800&q=80' },
        { _id: '2', title: 'Wildlife Safari', image: 'https://images.unsplash.com/photo-1564760055775-d63b17a55c44?w=800&q=80' },
        { _id: '3', title: 'Temple Exploration', image: 'https://images.unsplash.com/photo-1545158535-c3e2a7a7e1e5?w=800&q=80' },
        { _id: '4', title: 'Beach Activities', image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&q=80' },
      ]);
    }
  };

  const differences = [
    {
      icon: <Users size={32} />,
      title: "Rich Cultural Heritage",
      description: "Explore 2,500+ years of history through ancient ruins, sacred temples, and vibrant traditions"
    },
    {
      icon: <Globe size={32} />,
      title: "Diverse Ecosystems",
      description: "From misty mountains to pristine beaches, 26 national parks showcase incredible biodiversity"
    },
    {
      icon: <Shield size={32} />,
      title: "Authentic Experiences",
      description: "Connect with local communities, taste traditional cuisine, and witness age-old crafts"
    },
    {
      icon: <Heart size={32} />,
      title: "Sustainable Tourism",
      description: "Travel responsibly with eco-friendly practices that preserve Sri Lanka's natural beauty"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Mitchell",
      location: "London, UK",
      rating: 5,
      text: "An absolutely magical journey! The Heritage Trail exceeded all expectations. Our guide was knowledgeable and the accommodations were top-notch.",
      avatar: "https://i.pravatar.cc/150?img=1",
      tour: "Heritage Trail"
    },
    {
      name: "David Chen",
      location: "Singapore",
      rating: 5,
      text: "The coastal paradise package was perfect for our family. Beautiful beaches, amazing food, and unforgettable whale watching experience.",
      avatar: "https://i.pravatar.cc/150?img=2",
      tour: "Coastal Paradise"
    },
    {
      name: "Emma Rodriguez",
      location: "Barcelona, Spain",
      rating: 5,
      text: "Tea country exceeded my dreams! The train ride through the hills was breathtaking. Highly recommend this experience to everyone.",
      avatar: "https://i.pravatar.cc/150?img=3",
      tour: "Tea Country Explorer"
    },
    {
      name: "James Wilson",
      location: "New York, USA",
      rating: 5,
      text: "Professional service from start to finish. The team made sure every detail was perfect. Can't wait to visit Sri Lanka again!",
      avatar: "https://i.pravatar.cc/150?img=4",
      tour: "Heritage Trail"
    }
  ];

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const scrollToContent = () => {
    window.scrollTo({
      top: window.innerHeight - 80,
      behavior: 'smooth'
    });
  };

  return (
    <div className="w-full overflow-x-hidden bg-[#0a0e0d] text-white">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-[1000] transition-all duration-400 ${
        scrollY > 50 
          ? 'bg-[rgba(10,14,13,0.95)] backdrop-blur-xl py-3 border-b border-white/8 shadow-[0_4px_20px_rgba(0,0,0,0.1)]' 
          : 'bg-transparent py-5'
      }`}>
        <div className="max-w-[1400px] mx-auto px-10 flex items-center justify-between">
          <button onClick={scrollToTop} className="flex items-center gap-3 transition-transform duration-300 hover:scale-105 bg-transparent border-none cursor-pointer">
            <div className="text-[32px] drop-shadow-[0_4px_8px_rgba(126,200,80,0.3)]">🌴</div>
            <span className="text-[26px] font-medium tracking-tight font-playfair text-white">SerenDibia</span>
          </button>
          
          <nav className="hidden md:flex gap-10">
            {['DESTINATIONS', 'TOURS', 'EXPERIENCES', 'GALLERY', 'ABOUT'].map((item, index) => (
              <button
                key={item}
                onClick={() => scrollToSection(index === 4 ? 'footer' : `${item.toLowerCase()}-section`)}
                className="text-white/90 text-[13px] tracking-[1.2px] font-medium transition-all duration-300 relative py-2 bg-transparent border-none cursor-pointer font-poppins hover:text-[#7ec850] after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-gradient-to-r after:from-[#7ec850] after:to-[#92d668] after:transition-all after:duration-300 hover:after:w-full"
              >
                {item}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => scrollToSection('tours-section')} 
              className="flex items-center gap-2 px-7 py-3 bg-gradient-to-br from-[#7ec850] to-[#92d668] text-[#0a0e0d] border-none rounded-full text-[13px] font-semibold tracking-wide cursor-pointer transition-all duration-300 shadow-[0_4px_20px_rgba(126,200,80,0.3)] hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(126,200,80,0.4)]"
            >
              <span>BOOK NOW</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden" id="hero-section">
        <div className="absolute top-0 left-0 right-0 bottom-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1562979314-bee7453e911c?w=1920&q=80" 
            alt="Sri Lanka Train"
            className="w-full h-[120%] object-cover object-center brightness-[0.7]"
            style={{ transform: `translateY(${scrollY * 0.5}px)` }}
          />
          <div className="absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-b from-[rgba(10,14,13,0.3)] to-[rgba(10,14,13,0.85)]" />
        </div>
        
        <div className="max-w-[1400px] mx-auto px-10 relative z-10 pt-[100px]">
          <div className={`transition-all duration-[1200ms] ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[30px]'}`}>
            <h1 className="text-[110px] font-semibold leading-[1.1] mb-4 font-playfair tracking-[-3px]">
              Explore <span className="italic bg-gradient-to-br from-[#d4af37] to-[#f2d06b] bg-clip-text text-transparent font-medium">Serendibia</span>
            </h1>
            <p className="text-[36px] font-normal mb-6 font-playfair text-white/95">The Soul of Sri Lanka</p>
            <p className="text-[17px] leading-[1.8] text-white/85 mb-[60px] max-w-[800px]">
              Embark on a cinematic journey through ancient temples, misty mountains,<br />
              pristine beaches, and rich cultural heritage of the pearl of the Indian Ocean.
            </p>

            <div className="max-w-[700px] mb-[100px]">
              <div className="flex items-center gap-4 bg-white/8 backdrop-blur-xl border border-white/15 rounded-[60px] py-2 px-7 transition-all duration-300 focus-within:bg-white/12 focus-within:border-[rgba(126,200,80,0.5)] focus-within:shadow-[0_10px_40px_rgba(126,200,80,0.2)]">
                <Search size={20} />
                <input 
                  type="text" 
                  placeholder="Search destinations, packages, experiences..." 
                  className="flex-1 bg-transparent border-none text-white text-[15px] outline-none placeholder:text-white/50"
                />
                <button className="px-8 py-3.5 bg-gradient-to-br from-[#7ec850] to-[#92d668] text-[#0a0e0d] border-none rounded-full text-sm font-semibold cursor-pointer transition-transform duration-300 hover:scale-105">
                  Search
                </button>
              </div>
            </div>

            <div 
              onClick={scrollToContent}
              className="flex flex-col items-center gap-4 text-white/70 text-[11px] tracking-[2px] cursor-pointer transition-colors duration-300 hover:text-[#7ec850]"
            >
              <span>SCROLL TO EXPLORE</span>
              <div className="animate-bounce">
                <ChevronDown size={24} />
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-20 right-20 flex gap-[60px] z-[2]">
          <div className="text-center">
            <div className="text-5xl font-bold text-[#7ec850] mb-2 font-poppins">500+</div>
            <div className="text-[13px] text-white/80 uppercase tracking-wide">Happy Travelers</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold text-[#7ec850] mb-2 font-poppins">{packages.length}+</div>
            <div className="text-[13px] text-white/80 uppercase tracking-wide">Tour Packages</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold text-[#7ec850] mb-2 font-poppins">4.9★</div>
            <div className="text-[13px] text-white/80 uppercase tracking-wide">Customer Rating</div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="bg-gradient-to-b from-white to-[#f8f9fa] py-40 relative" id="about-section">
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-20 max-w-[900px] mx-auto">
            <div className="inline-flex items-center gap-2.5 px-7 py-3 bg-[rgba(126,200,80,0.08)] border border-[rgba(126,200,80,0.2)] rounded-full text-[#2d5016] text-xs tracking-[2px] font-semibold mb-9">
              <MapPin size={18} />
              <span>DISCOVER SRI LANKA</span>
            </div>
            
            <h2 className="text-[72px] font-semibold leading-[1.2] mb-8 text-[#1a1a1a] font-playfair tracking-tight">
              From misty hills<br />
              <span className="italic bg-gradient-to-br from-[#2196f3] to-[#42a5f5] bg-clip-text text-transparent font-medium">to golden shores</span>
            </h2>

            <p className="text-lg leading-[1.9] text-[#555] max-w-[800px] mx-auto">
              Sri Lanka is a teardrop of wonder, where ancient civilizations meet 
              untouched nature, and every moment becomes a cherished memory. 
              Experience the warmth of its people, the richness of its culture, 
              and the breathtaking beauty of its landscapes.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-[60px] mb-20 items-center px-10">
            <div className="relative h-[500px] overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.15)] transition-all duration-500 rounded-[200px_20px_200px_20px] -rotate-3 hover:rotate-0 hover:-translate-y-2.5 hover:shadow-[0_40px_100px_rgba(0,0,0,0.2)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
              <img 
                src="https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?w=1200&q=80" 
                alt="Nine Arch Bridge Train"
                className="w-full h-full object-cover transition-transform duration-600 hover:scale-105"
              />
            </div>

            <div className="relative h-[500px] overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.15)] transition-all duration-500 rounded-[20px_200px_20px_200px] rotate-3 hover:rotate-0 hover:-translate-y-2.5 hover:shadow-[0_40px_100px_rgba(0,0,0,0.2)] opacity-0 animate-[fadeInUp_0.8s_ease-out_0.2s_forwards]">
              <img 
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80" 
                alt="Sri Lanka Waterfall"
                className="w-full h-full object-cover transition-transform duration-600 hover:scale-105"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-10 mb-[60px]">
            {[
              { number: "08", label: "UNESCO Sites", desc: "World Heritage treasures" },
              { number: "1340", label: "KM Beaches", desc: "Coastline of paradise" },
              { number: "26", label: "National Parks", desc: "Protected wildlife reserves" },
              { number: "2500+", label: "Years History", desc: "Ancient civilization legacy" }
            ].map((stat, index) => (
              <div 
                key={index}
                className="bg-white p-10 rounded-3xl text-center shadow-[0_10px_40px_rgba(0,0,0,0.06)] transition-all duration-400 border border-black/[0.03] hover:-translate-y-2 hover:shadow-[0_20px_60px_rgba(0,0,0,0.1)] hover:border-[rgba(126,200,80,0.2)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-6xl font-bold bg-gradient-to-br from-[#2196f3] to-[#42a5f5] bg-clip-text text-transparent mb-3 font-poppins leading-none">
                  {stat.number}
                </div>
                <div className="text-sm text-[#1a1a1a] uppercase tracking-[1.5px] font-semibold mb-2">
                  {stat.label}
                </div>
                <p className="text-[13px] text-[#777] leading-[1.6]">{stat.desc}</p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link href="/about">
              <button className="inline-flex items-center gap-3 px-10 py-4 bg-gradient-to-br from-[#2196f3] to-[#42a5f5] text-white border-none rounded-full text-[15px] font-semibold cursor-pointer transition-all duration-300 shadow-[0_8px_24px_rgba(33,150,243,0.3)] hover:-translate-y-0.5 hover:shadow-[0_12px_32px_rgba(33,150,243,0.4)]">
                Learn More About Sri Lanka
                <ArrowRight size={16} />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Tours Section */}
      <section className="bg-gradient-to-b from-[#0a0e0d] via-[#1a2e1a] to-[#0a0e0d] py-[140px] relative" id="tours-section">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[radial-gradient(circle,_rgba(126,200,80,0.05)_0%,_transparent_70%)] pointer-events-none" />
        
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-[100px] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
            <div className="inline-flex items-center gap-2.5 px-6 py-2.5 bg-[rgba(212,175,55,0.15)] border border-[rgba(212,175,55,0.3)] rounded-full text-[#d4af37] text-[11px] tracking-[2.5px] font-semibold mb-7 backdrop-blur-sm">
              <span className="w-2 h-2 bg-[#d4af37] rounded-full animate-pulse" />
              CURATED JOURNEYS
            </div>
            <h2 className="text-[80px] font-semibold leading-[1.2] mb-7 font-playfair tracking-[-2px]">
              Tour <span className="italic bg-gradient-to-br from-[#d4af37] to-[#f2d06b] bg-clip-text text-transparent font-medium">Packages</span>
            </h2>
            <p className="text-[17px] leading-[1.8] text-white/75">
              Handcrafted itineraries designed for the discerning traveler. Each journey<br />
              promises authentic experiences and unforgettable memories.
            </p>
          </div>

          {loading ? (
            <div className="text-center py-[100px]">
              <div className="w-[60px] h-[60px] border-4 border-[rgba(126,200,80,0.2)] border-t-[#7ec850] rounded-full mx-auto mb-5 animate-spin" />
              <p className="text-white/70 text-base">Loading amazing packages...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-12 mb-[60px]">
                {packages.map((tour, index) => (
                  <div
                    key={tour._id}
                    className="bg-white/[0.02] border border-white/8 rounded-3xl overflow-hidden transition-all duration-500 backdrop-blur-sm hover:-translate-y-3 hover:border-[rgba(126,200,80,0.3)] hover:shadow-[0_30px_80px_rgba(0,0,0,0.5)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                    style={{ animationDelay: `${index * 0.15}s` }}
                  >
                    <div className="relative h-80 overflow-hidden group">
                      <img 
                        src={tour.image} 
                        alt={tour.title} 
                        className="w-full h-full object-cover transition-transform duration-[800ms] group-hover:scale-110"
                      />
                      <div className="absolute top-6 right-6 flex items-center gap-1.5 px-4 py-2 bg-gradient-to-br from-[#7ec850] to-[#92d668] text-white rounded-3xl text-[11px] font-bold tracking-wide shadow-[0_4px_16px_rgba(126,200,80,0.4)]">
                        <Star size={12} fill="#fff" />
                        BEST SELLER
                      </div>
                      <div className="absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-b from-transparent to-[rgba(0,0,0,0.7)] flex items-end justify-center p-6 opacity-0 transition-opacity duration-400 group-hover:opacity-100">
                        <Link href={`/package/${tour._id}`}>
                          <button className="flex items-center gap-2 px-6 py-3 bg-white/95 text-[#0a0e0d] border-none rounded-full text-[13px] font-semibold cursor-pointer transition-all duration-300 hover:bg-white hover:scale-105">
                            <Search size={16} />
                            Quick View
                          </button>
                        </Link>
                      </div>
                    </div>

                    <div className="p-8">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="text-[26px] font-semibold font-playfair text-white tracking-tight">{tour.title}</h3>
                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[rgba(255,184,0,0.15)] rounded-2xl text-sm font-semibold text-[#FFB800]">
                          <Star size={14} fill="#FFB800" color="#FFB800" />
                          <span>{tour.rating}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2.5 text-white/65 text-sm mb-5">
                        <Calendar size={14} />
                        <span>{tour.duration}</span>
                      </div>

                      <div className="flex flex-wrap gap-2.5 mb-6">
                        {tour.locations && tour.locations.map((loc, i) => (
                          <span key={i} className="flex items-center gap-1.5 px-3.5 py-2 bg-[rgba(126,200,80,0.12)] border border-[rgba(126,200,80,0.25)] rounded-3xl text-[#7ec850] text-[11px] font-semibold tracking-wide">
                            <MapPin size={10} />
                            {loc}
                          </span>
                        ))}
                      </div>

                      <div className="flex flex-col gap-3 mb-7 py-6 border-t border-b border-white/8">
                        {tour.highlights && tour.highlights.slice(0, 3).map((highlight, i) => (
                          <div key={i} className="flex items-center gap-3 text-sm text-white/75">
                            <div className="w-2 h-2 bg-gradient-to-br from-[#7ec850] to-[#92d668] rounded-full flex-shrink-0" />
                            <span>{highlight}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="flex flex-col gap-1">
                          <span className="text-xs text-white/50 uppercase tracking-wide">Starting from</span>
                          <div className="flex items-baseline gap-1">
                            <span className="text-xl font-semibold text-white">$</span>
                            <span className="text-[42px] font-bold text-white font-poppins leading-none">{tour.price}</span>
                            <span className="text-sm text-white/60">/ person</span>
                          </div>
                        </div>
                        <Link href={`/package/${tour._id}`}>
                          <button className="flex items-center gap-2 px-7 py-4 bg-gradient-to-br from-[#7ec850] to-[#92d668] text-[#0a0e0d] border-none rounded-full text-[13px] font-bold tracking-wide cursor-pointer transition-all duration-300 shadow-[0_4px_16px_rgba(126,200,80,0.3)] hover:translate-x-1 hover:shadow-[0_6px_20px_rgba(126,200,80,0.4)]">
                            <span>View Details</span>
                            <ArrowRight size={14} />
                          </button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-center gap-[60px] py-[60px] px-10 bg-white/[0.03] border border-white/8 rounded-3xl mb-[60px] backdrop-blur-sm">
                <div className="text-center">
                  <div className="text-[52px] font-bold bg-gradient-to-br from-[#7ec850] to-[#92d668] bg-clip-text text-transparent mb-3 font-poppins">{packages.length}+</div>
                  <div className="text-sm text-white/70 uppercase tracking-[1.5px] font-semibold">Tour Packages</div>
                </div>
                <div className="w-px h-20 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
                <div className="text-center">
                  <div className="text-[52px] font-bold bg-gradient-to-br from-[#7ec850] to-[#92d668] bg-clip-text text-transparent mb-3 font-poppins">4.9★</div>
                  <div className="text-sm text-white/70 uppercase tracking-[1.5px] font-semibold">Average Rating</div>
                </div>
                <div className="w-px h-20 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
                <div className="text-center">
                  <div className="text-[52px] font-bold bg-gradient-to-br from-[#7ec850] to-[#92d668] bg-clip-text text-transparent mb-3 font-poppins">500+</div>
                  <div className="text-sm text-white/70 uppercase tracking-[1.5px] font-semibold">Happy Travelers</div>
                </div>
              </div>
            </>
          )}

          <div className="text-center mt-20">
            <Link href="/packages">
              <button className="inline-flex items-center gap-3 px-14 py-4 bg-transparent text-white border-2 border-white/20 rounded-[60px] text-[15px] font-semibold tracking-wide cursor-pointer transition-all duration-400 hover:bg-gradient-to-br hover:from-[#7ec850] hover:to-[#92d668] hover:border-[#7ec850] hover:text-[#0a0e0d] hover:-translate-y-0.5 hover:shadow-[0_8px_32px_rgba(126,200,80,0.3)]">
                <span>Explore All Packages</span>
                <ArrowRight size={18} />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Destinations Section */}
      <section className="bg-gradient-to-b from-[#f8f9fa] to-white py-[140px]" id="destinations-section">
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-[100px] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
            <div className="inline-flex items-center gap-2.5 px-6 py-2.5 bg-[rgba(126,200,80,0.12)] border border-[rgba(126,200,80,0.25)] rounded-full text-[#2d5016] text-[11px] tracking-[2.5px] font-semibold mb-7">
              <Globe size={14} />
              UNFORGETTABLE PLACES
            </div>
            <h2 className="text-[80px] font-semibold leading-[1.2] mb-6 font-playfair tracking-[-2px] text-[#1a1a1a]">
              Beautiful <span className="italic bg-gradient-to-br from-[#2d5016] to-[#7ec850] bg-clip-text text-transparent font-medium">Destinations</span>
            </h2>
            <p className="text-[17px] text-[#666] mt-4">
              Discover the most breathtaking locations across the island
            </p>
          </div>

          {loading ? (
            <div className="text-center py-[100px]">
              <div className="w-[60px] h-[60px] border-4 border-[rgba(126,200,80,0.2)] border-t-[#7ec850] rounded-full mx-auto mb-5 animate-spin" />
              <p className="text-[#666] text-base">Loading destinations...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-12 mb-[60px]">
                {destinations.map((dest, index) => (
                  <Link href={`/destination/${dest._id}`} key={dest._id}>
                    <div 
                      className="relative rounded-3xl overflow-hidden h-[480px] cursor-pointer transition-all duration-500 shadow-[0_20px_60px_rgba(0,0,0,0.1)] hover:-translate-y-4 hover:shadow-[0_30px_80px_rgba(0,0,0,0.15)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className="relative w-full h-full group">
                        <img 
                          src={dest.image} 
                          alt={dest.name}
                          className="w-full h-full object-cover transition-transform duration-[800ms] group-hover:scale-[1.15]"
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-b from-transparent to-[rgba(0,0,0,0.9)] p-12 text-white">
                          <MapPin size={20} className="mb-4 drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]" />
                          <h3 className="text-[32px] font-semibold mb-3 font-playfair">{dest.name}</h3>
                          <p className="flex items-center gap-2 text-[15px] text-white/95 mb-5">
                            {dest.location}
                          </p>
                          <button className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-br from-[#7ec850] to-[#92d668] text-white border-none rounded-full text-[13px] font-semibold cursor-pointer opacity-0 translate-y-5 transition-all duration-400 group-hover:opacity-100 group-hover:translate-y-0">
                            Explore
                            <ArrowRight size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              <div className="text-center">
                <Link href="/destinations">
                  <button className="inline-flex items-center gap-3 px-14 py-4 bg-gradient-to-br from-[#2d5016] to-[#3d6b1f] text-white border-none rounded-[60px] text-[15px] font-semibold cursor-pointer transition-all duration-300 shadow-[0_8px_32px_rgba(45,80,22,0.3)] hover:-translate-y-0.5 hover:shadow-[0_12px_40px_rgba(45,80,22,0.4)]">
                    <span>View All {destinations.length} Destinations</span>
                    <ArrowRight size={18} />
                  </button>
                </Link>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Experiences Section */}
      <section className="bg-gradient-to-b from-white to-[#f8f9fa] py-[140px]" id="experiences-section">
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-[100px] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
            <div className="inline-flex items-center gap-2.5 px-6 py-2.5 bg-[rgba(33,150,243,0.08)] border border-[rgba(33,150,243,0.2)] rounded-full text-[#1565c0] text-[11px] tracking-[2.5px] font-semibold mb-7">
              <Heart size={14} />
              TAILORED EXPERIENCES
            </div>
            <h2 className="text-[80px] font-semibold leading-[1.2] mb-6 font-playfair tracking-[-2px] text-[#1a1a1a]">
              Immersive <span className="italic bg-gradient-to-br from-[#2196f3] to-[#42a5f5] bg-clip-text text-transparent font-medium">Experiences</span>
            </h2>
            <p className="text-[17px] text-[#666] mt-4">
              Curated activities that bring you closer to Sri Lanka's culture and nature
            </p>
          </div>

          <div className="grid grid-cols-4 gap-9">
            {experiences.map((exp, index) => (
              <Link href={`/gallery/${exp._id}`} key={exp._id}>
                <div 
                  className="text-center cursor-pointer transition-transform duration-400 hover:-translate-y-2 opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="relative w-full h-[280px] rounded-2xl overflow-hidden mb-5 shadow-[0_16px_48px_rgba(0,0,0,0.08)] group">
                    <img 
                      src={exp.image} 
                      alt={exp.title}
                      className="w-full h-full object-cover transition-transform duration-600 group-hover:scale-110"
                    />
                    <div className="absolute top-0 left-0 right-0 bottom-0 bg-[rgba(33,150,243,0.8)] flex items-center justify-center opacity-0 transition-opacity duration-400 group-hover:opacity-100">
                      <ArrowRight size={32} className="text-white" />
                    </div>
                  </div>
                  <h3 className="text-[19px] font-semibold text-[#333]">{exp.title}</h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-20">
            <Link href="/gallery">
              <button className="inline-flex items-center gap-3 px-14 py-4 bg-gradient-to-br from-[#2196f3] to-[#42a5f5] text-white border-none rounded-[60px] text-[15px] font-semibold cursor-pointer transition-all duration-300 shadow-[0_8px_32px_rgba(33,150,243,0.3)] hover:-translate-y-0.5 hover:shadow-[0_12px_40px_rgba(33,150,243,0.4)]">
                <span>Discover All Experiences</span>
                <ArrowRight size={18} />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Difference Section */}
      <section className="bg-gradient-to-br from-[#f0f4f8] to-[#e8eff5] py-[140px]" id="difference-section">
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-[100px] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
            <div className="inline-flex items-center gap-2.5 px-6 py-2.5 bg-[rgba(212,175,55,0.12)] border border-[rgba(212,175,55,0.25)] rounded-full text-[#9d7c2a] text-[11px] tracking-[2.5px] font-semibold mb-7">
              <Shield size={14} />
              WHY CHOOSE US
            </div>
            <h2 className="text-[80px] font-semibold leading-[1.2] mb-6 font-playfair tracking-[-2px] text-[#1a1a1a]">
              The Serendibia <span className="italic bg-gradient-to-br from-[#d4af37] to-[#f2d06b] bg-clip-text text-transparent font-medium">Difference</span>
            </h2>
            <p className="text-[17px] text-[#666] mt-4">
              What makes us the preferred choice for your Sri Lankan adventure
            </p>
          </div>

          <div className="grid grid-cols-4 gap-12">
            {differences.map((diff, index) => (
              <div 
                key={index} 
                className="bg-white p-12 rounded-3xl text-center shadow-[0_16px_48px_rgba(0,0,0,0.06)] transition-all duration-500 border border-black/[0.03] hover:-translate-y-3 hover:shadow-[0_24px_64px_rgba(0,0,0,0.1)] hover:border-[rgba(126,200,80,0.2)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-24 h-24 mx-auto mb-7 flex items-center justify-center bg-gradient-to-br from-[#2d5016] to-[#7ec850] rounded-full text-white shadow-[0_12px_32px_rgba(45,80,22,0.25)]">
                  {diff.icon}
                </div>
                <h3 className="text-2xl font-semibold text-[#1a1a1a] mb-4">{diff.title}</h3>
                <p className="text-base leading-[1.8] text-[#666]">{diff.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-gradient-to-b from-[#1a2e1a] via-[#0a0e0d] to-[#1a2e1a] py-[140px] relative" id="testimonials-section">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[radial-gradient(circle,_rgba(126,200,80,0.05)_0%,_transparent_70%)] pointer-events-none" />
        
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="text-center mb-[100px] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]">
            <div className="inline-flex items-center gap-2.5 px-6 py-2.5 bg-[rgba(212,175,55,0.15)] border border-[rgba(212,175,55,0.3)] rounded-full text-[#d4af37] text-[11px] tracking-[2.5px] font-semibold mb-7 backdrop-blur-sm">
              <Users size={14} />
              TRAVELER STORIES
            </div>
            <h2 className="text-[80px] font-semibold leading-[1.2] mb-7 font-playfair tracking-[-2px]">
              What Our <span className="italic bg-gradient-to-br from-[#d4af37] to-[#f2d06b] bg-clip-text text-transparent font-medium">Travelers</span> Say
            </h2>
            <p className="text-[17px] leading-[1.8] text-white/75">
              Real experiences from real travelers who discovered Sri Lanka with us
            </p>
          </div>

          <div className="grid grid-cols-4 gap-9">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index} 
                className="bg-white/[0.03] border border-white/8 rounded-3xl p-9 backdrop-blur-sm transition-all duration-500 relative hover:bg-white/[0.06] hover:border-[rgba(126,200,80,0.3)] hover:-translate-y-2 hover:shadow-[0_20px_60px_rgba(0,0,0,0.3)] opacity-0 animate-[fadeInUp_0.8s_ease-out_forwards]"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-[80px] text-[rgba(126,200,80,0.2)] leading-none absolute top-5 right-6 font-serif">"</div>
                <div className="flex gap-1.5 mb-5">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={14} fill="#FFB800" color="#FFB800" />
                  ))}
                </div>
                <p className="text-[15px] leading-[1.8] text-white/90 mb-7 italic">{testimonial.text}</p>
                <div className="flex gap-3.5 items-center">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-[rgba(126,200,80,0.3)]"
                  />
                  <div>
                    <h4 className="text-[17px] font-semibold text-white mb-1.5">{testimonial.name}</h4>
                    <p className="text-[13px] text-white/65 mb-1.5 flex items-center gap-1">
                      <MapPin size={12} /> {testimonial.location}
                    </p>
                    <span className="text-xs text-[#7ec850] font-semibold">{testimonial.tour}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0a0e0d] pt-[100px] pb-10 border-t border-white/8" id="footer">
        <div className="max-w-[1400px] mx-auto px-10">
          <div className="grid grid-cols-[1.5fr_1fr_1fr_1fr] gap-20 mb-20">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="text-4xl">🌴</div>
                <h3 className="text-[28px] font-medium font-playfair bg-gradient-to-br from-[#7ec850] to-[#92d668] bg-clip-text text-transparent">SerenDibia</h3>
              </div>
              <p className="text-white/70 text-[15px] leading-[1.7] mb-8 max-w-[350px]">
                Experience the soul of Sri Lanka with authentic, sustainable tours crafted with love.
              </p>
              <div className="flex gap-4">
                {['f', 'in', 'ig', 'tw'].map((social) => (
                  <a 
                    key={social}
                    href="#" 
                    className="w-11 h-11 flex items-center justify-center bg-white/5 border border-white/10 rounded-full text-white/70 no-underline font-semibold transition-all duration-300 hover:bg-gradient-to-br hover:from-[#7ec850] hover:to-[#92d668] hover:text-white hover:border-transparent hover:-translate-y-0.5"
                  >
                    {social}
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-7 text-white">Quick Links</h4>
              {['Destinations', 'Tour Packages', 'Gallery', 'About Us', 'Contact'].map((link) => (
                <Link 
                  key={link}
                  href={`/${link.toLowerCase().replace(' ', '-')}`}
                  className="block text-white/70 no-underline mb-3.5 text-[15px] transition-all duration-300 hover:text-[#7ec850] hover:pl-1"
                >
                  {link}
                </Link>
              ))}
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-7 text-white">Popular Tours</h4>
              {['Heritage Trail', 'Coastal Paradise', 'Tea Country', 'Wildlife Safari', 'Cultural Journey'].map((tour) => (
                <Link 
                  key={tour}
                  href="/packages"
                  className="block text-white/70 no-underline mb-3.5 text-[15px] transition-all duration-300 hover:text-[#7ec850] hover:pl-1"
                >
                  {tour}
                </Link>
              ))}
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-7 text-white">Contact Us</h4>
              {[
                '📧 info@serendibia.com',
                '📞 +94 77 123 4567',
                '📍 Colombo, Sri Lanka',
                '🕒 Mon - Sat: 9AM - 6PM'
              ].map((contact) => (
                <p key={contact} className="block text-white/70 mb-3.5 text-[15px]">{contact}</p>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center pt-10 border-t border-white/8">
            <p className="text-white/50 text-sm">
              &copy; 2026 SerenDibia. All rights reserved. Made with ❤️ in Sri Lanka
            </p>
            <div className="flex gap-8">
              <Link href="/privacy" className="text-white/60 no-underline text-sm transition-colors duration-300 hover:text-[#7ec850]">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-white/60 no-underline text-sm transition-colors duration-300 hover:text-[#7ec850]">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}