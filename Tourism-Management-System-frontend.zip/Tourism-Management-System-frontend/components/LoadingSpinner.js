import { Spin } from 'antd';

export default function LoadingSpinner({ fullScreen = false }) {
  const style = fullScreen ? {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh'
  } : {
    display: 'flex',
    justifyContent: 'center',
    padding: '20px'
  };

  return (
    <div style={style}>
      <Spin size="large" />
    </div>
  );
}