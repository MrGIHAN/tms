'use client';

import { Layout, Menu, Avatar, Dropdown, Badge, Space, Typography } from 'antd';
import {
  DashboardOutlined,
  UserOutlined,
  CarOutlined,
  EnvironmentOutlined,
  BookOutlined,
  DollarOutlined,
  SettingOutlined,
  BellOutlined,
  LogoutOutlined,
  TeamOutlined,
  CalendarOutlined,
  MessageOutlined,
  StarOutlined,
  FileTextOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  SafetyOutlined,
} from '@ant-design/icons';
import { useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import type { MenuProps } from 'antd';

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const router = useRouter();
  const pathname = usePathname();
  const { user, signout } = useAuth();

  // Menu items configuration
  const menuItems: MenuProps['items'] = [
    {
      key: '/admin/dashboard',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
    },
    {
      key: 'user-management',
      icon: <TeamOutlined />,
      label: 'User Management',
      children: [
        {
          key: '/admin/drivers',
          label: 'Drivers List',
        },
        {
          key: '/admin/passengers',
          label: 'Passenger List',
        },
      ],
    },
    {
      key: 'tour-management',
      icon: <BookOutlined />,
      label: 'Tour Management',
      children: [
        {
          key: '/admin/tours',
          label: 'All Tours',
        },
        {
          key: '/admin/tours/add',
          label: 'Add Tour',
        },
        {
          key: '/admin/bookings',
          label: 'Booking Management',
        },
      ],
    },
    {
      key: '/admin/vehicles',
      icon: <CarOutlined />,
      label: 'Vehicle Management',
    },
    {
      key: '/admin/payments',
      icon: <DollarOutlined />,
      label: 'Payment Management',
    },
    {
      key: '/admin/locations',
      icon: <EnvironmentOutlined />,
      label: 'Locations & Destinations',
    },
    {
      key: '/admin/schedule',
      icon: <CalendarOutlined />,
      label: 'Availability & Schedule',
    },
    {
      key: '/admin/reviews',
      icon: <StarOutlined />,
      label: 'Reviews & Ratings',
    },
    {
      key: '/admin/communications',
      icon: <MessageOutlined />,
      label: 'Communications',
    },
    {
      key: '/admin/notifications',
      icon: <BellOutlined />,
      label: 'Notifications Control',
    },
    {
      key: '/admin/reports',
      icon: <FileTextOutlined />,
      label: 'Reports & Analytics',
    },
    {
      key: '/admin/settings',
      icon: <SettingOutlined />,
      label: 'System Configuration',
    },
  ];

  // User dropdown menu
  const userMenuItems: MenuProps['items'] = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'My Profile',
      onClick: () => router.push('/admin/profile'),
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: 'Settings',
      onClick: () => router.push('/admin/settings'),
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Logout',
      danger: true,
      onClick: signout,
    },
  ];

  const handleMenuClick: MenuProps['onClick'] = (e) => {
    router.push(e.key);
  };

  return (
    <Layout className="min-h-screen">
      {/* Sidebar */}
      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        className="bg-gradient-to-b from-blue-900 to-blue-700"
        width={250}
        style={{
          overflow: 'auto',
          height: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
        }}
      >
        <div className="flex items-center justify-center h-16 bg-blue-800">
          <SafetyOutlined className="text-3xl text-yellow-400" />
          {!collapsed && (
            <Text className="ml-2 text-white font-bold text-lg">
              Tourism Admin
            </Text>
          )}
        </div>

        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={[pathname]}
          items={menuItems}
          onClick={handleMenuClick}
          className="bg-transparent border-0"
        />
      </Sider>

      {/* Main Layout */}
      <Layout style={{ marginLeft: collapsed ? 80 : 250, transition: 'all 0.2s' }}>
        {/* Header */}
        <Header className="bg-white shadow-md px-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center">
            {collapsed ? (
              <MenuUnfoldOutlined
                className="text-xl cursor-pointer hover:text-blue-600 transition-colors"
                onClick={() => setCollapsed(!collapsed)}
              />
            ) : (
              <MenuFoldOutlined
                className="text-xl cursor-pointer hover:text-blue-600 transition-colors"
                onClick={() => setCollapsed(!collapsed)}
              />
            )}
          </div>

          <Space size="large">
            {/* Notifications */}
            <Badge count={5} className="cursor-pointer">
              <BellOutlined className="text-xl hover:text-blue-600 transition-colors" />
            </Badge>

            {/* User Dropdown */}
            <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
              <div className="flex items-center cursor-pointer hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors">
                <Avatar
                  icon={<UserOutlined />}
                  className="bg-blue-600"
                />
                <div className="ml-2 hidden md:block">
                  <Text className="block font-semibold text-sm">
                    {user?.fullName || 'Admin'}
                  </Text>
                  <Text className="block text-xs text-gray-500">
                    Administrator
                  </Text>
                </div>
              </div>
            </Dropdown>
          </Space>
        </Header>

        {/* Content */}
        <Content className="m-6 p-6 bg-gray-50 min-h-[calc(100vh-88px)] rounded-lg">
          {children}
        </Content>
      </Layout>
    </Layout>
  );
}