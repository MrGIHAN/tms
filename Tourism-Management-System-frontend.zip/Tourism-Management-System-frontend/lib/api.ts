// lib/api.ts
import axios from "axios";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

// ==========================
// Helper function for headers
// ==========================
const getAuthHeaders = () => {
  if (typeof window === "undefined") return { "Content-Type": "application/json" }; // SSR safe
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

// ==========================
// CUSTOMERS API
// ==========================
export const fetchCustomers = async () => {
  const res = await fetch(`${BASE_URL}/customers`, {
    method: "GET",
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error("Failed to fetch customers");
  return res.json();
};

// ==========================
// DRIVERS API
// ==========================
export const fetchDrivers = async () => {
  const res = await fetch(`${BASE_URL}/drivers`, {
    method: "GET",
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error("Failed to fetch drivers");
  return res.json();
};

// ==========================
// PACKAGES / TOURS API
// ==========================
export const fetchPackages = async () => {
  const res = await fetch(`${BASE_URL}/packages`, {
    method: "GET",
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error("Failed to fetch packages");
  return res.json();
};

// Alias for fetchPackages
export const fetchTours = fetchPackages;

// ==========================
// HOTELS API (CRUD with Axios)
// ==========================
const HOTELS_URL = `${BASE_URL}/hotels`;

export const fetchHotels = async () => {
  const res = await axios.get(HOTELS_URL, { headers: getAuthHeaders() });
  return res.data;
};

export const createHotel = async (hotel: any) => {
  const res = await axios.post(HOTELS_URL, hotel, { headers: getAuthHeaders() });
  return res.data;
};

export const updateHotel = async (id: string, hotel: any) => {
  const res = await axios.put(`${HOTELS_URL}/${id}`, hotel, { headers: getAuthHeaders() });
  return res.data;
};

export const deleteHotel = async (id: string) => {
  const res = await axios.delete(`${HOTELS_URL}/${id}`, { headers: getAuthHeaders() });
  return res.data;
};

// ==========================
// REVIEWS API
// ==========================
export const fetchReviews = async () => {
  const res = await fetch(`${BASE_URL}/reviews`, {
    method: "GET",
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error("Failed to fetch reviews");
  return res.json();
};

// ==========================
// AUTH API
// ==========================
export const signin = async (data: { username: string; password: string }) => {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Login failed");
  return res.json();
};

export const signup = async (data: any) => {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Signup failed");
  return res.json();
};



