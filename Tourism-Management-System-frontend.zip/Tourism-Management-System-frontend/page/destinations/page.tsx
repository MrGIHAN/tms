"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Users, Calendar, MapPin, Search, DollarSign, Package } from "lucide-react";

export default function PackagesPage() {
  const [packages, setPackages] = useState([]);
  const [filteredPackages, setFilteredPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [priceFilter, setPriceFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");

  const API_URL =
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

  const BASE_URL = API_URL.replace("/api", "");

  // Safe image resolver
  const resolveImage = (path) => {
    if (!path) return "/default-package.jpg";
    if (path.startsWith("http")) return path;
    return `${BASE_URL}${path}`;
  };

  // Fetch packages
  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const res = await fetch(`${API_URL}/packages`);

        if (!res.ok) {
          setPackages([]);
          return;
        }

        const data = await res.json();

        if (Array.isArray(data)) {
          setPackages(data);
          setFilteredPackages(data);
        } else {
          setPackages([]);
          setFilteredPackages([]);
        }
      } catch (error) {
        console.error("Error fetching packages:", error);
        setPackages([]);
      } finally {
        setLoading(false);
      }
    };

    fetchPackages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Extract unique locations for filter
  const uniqueLocations = [
    ...new Set(
      packages.flatMap((pkg) =>
        Array.isArray(pkg.location) ? pkg.location : []
      )
    ),
  ].sort();

  // Filtering
  useEffect(() => {
    let filtered = [...packages];

    // Search filter
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase();

      filtered = filtered.filter((pkg) => {
        const name = pkg.packageName?.toLowerCase() || "";
        const desc = pkg.description?.toLowerCase() || "";
        const locations = Array.isArray(pkg.location)
          ? pkg.location.join(" ").toLowerCase()
          : "";

        return (
          name.includes(query) ||
          desc.includes(query) ||
          locations.includes(query)
        );
      });
    }

    // Price filter
    if (priceFilter !== "all") {
      filtered = filtered.filter((pkg) => {
        const price = Number(pkg.price) || 0;

        if (priceFilter === "budget") return price < 500;
        if (priceFilter === "mid") return price >= 500 && price < 1000;
        if (priceFilter === "luxury") return price >= 1000;

        return true;
      });
    }

    // Location filter
    if (locationFilter !== "all") {
      filtered = filtered.filter((pkg) =>
        Array.isArray(pkg.location)
          ? pkg.location.some((loc) =>
              loc.toLowerCase().includes(locationFilter.toLowerCase())
            )
          : false
      );
    }

    setFilteredPackages(filtered);
  }, [packages, searchQuery, priceFilter, locationFilter]);

  // Reset filters
  const resetFilters = () => {
    setSearchQuery("");
    setPriceFilter("all");
    setLocationFilter("all");
  };

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading packages...</p>
      </div>
    );
  }

  return (
    <div className="packages-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <h1>Explore Our Tour Packages</h1>
          <p>Discover amazing destinations and unforgettable experiences</p>
        </div>
      </section>

      {/* Filters Section */}
      <section className="filters-section">
        <div className="container">
          <div className="filters-wrapper">
            {/* Search */}
            <div className="search-box">
              <Search size={20} />
              <input
                type="text"
                placeholder="Search packages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Price Filter */}
            <div className="filter-group">
              <label>
                <DollarSign size={18} />
                Price Range
              </label>
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
              >
                <option value="all">All Prices</option>
                <option value="budget">Budget (&lt; $500)</option>
                <option value="mid">Mid-Range ($500 - $1000)</option>
                <option value="luxury">Luxury ($1000+)</option>
              </select>
            </div>

            {/* Location Filter */}
            <div className="filter-group">
              <label>
                <MapPin size={18} />
                Location
              </label>
              <select
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
              >
                <option value="all">All Locations</option>
                {uniqueLocations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            {/* Reset Button */}
            {(searchQuery || priceFilter !== "all" || locationFilter !== "all") && (
              <button className="reset-btn" onClick={resetFilters}>
                Reset Filters
              </button>
            )}
          </div>

          {/* Results Count */}
          <div className="results-info">
            Showing {filteredPackages.length} of {packages.length} packages
          </div>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="packages-section">
        <div className="container">
          {filteredPackages.length === 0 ? (
            <div className="no-results">
              <Package size={64} color="#ccc" />
              <h3>No packages found</h3>
              <p>Try adjusting your filters or search query</p>
              <button className="reset-btn" onClick={resetFilters}>
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="packages-grid">
              {filteredPackages.map((pkg) => {
                const rawThumbnail =
                  pkg.photoGallery?.find((p) => p.isThumbnail)?.photoUrl ||
                  pkg.photoGallery?.[0]?.photoUrl;

                const thumbnail = resolveImage(rawThumbnail);

                return (
                  <Link href={`/package/${pkg._id}`} key={pkg._id}>
                    <div className="package-card">
                      <div className="package-image">
                        <img
                          src={thumbnail}
                          alt={pkg.packageName || "Package"}
                          onError={(e) => {
                            e.target.src = "/default-package.jpg";
                          }}
                        />
                        <div className="price-badge">
                          ${Number(pkg.price || 0).toLocaleString()}
                        </div>
                      </div>

                      <div className="package-content">
                        <h3>{pkg.packageName || "Untitled Package"}</h3>

                        {Array.isArray(pkg.location) &&
                          pkg.location.length > 0 && (
                            <div className="location-tag">
                              <MapPin size={14} />
                              {pkg.location.join(", ")}
                            </div>
                          )}

                        <p className="description">
                          {pkg.description
                            ? pkg.description.length > 120
                              ? pkg.description.substring(0, 120) + "..."
                              : pkg.description
                            : "No description available"}
                        </p>

                        <div className="package-meta">
                          <div className="meta-item">
                            <Users size={16} />
                            <span>Up to {pkg.maximumPassenger || 0}</span>
                          </div>

                          <div className="meta-item">
                            <Calendar size={16} />
                            <span>{pkg.itinerary?.length || 0} days</span>
                          </div>
                        </div>

                        <button className="view-details-btn">
                          View Details
                        </button>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <style jsx>{`
        .packages-page {
          min-height: 100vh;
          background: #f8f9fa;
        }

        .container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 0 40px;
        }

        /* Hero Section */
        .hero-section {
          background: linear-gradient(135deg, #7ec850 0%, #92d668 100%);
          color: white;
          padding: 80px 0;
          text-align: center;
        }

        .hero-section h1 {
          font-size: 48px;
          font-weight: 700;
          margin-bottom: 16px;
          font-family: 'Playfair Display', serif;
        }

        .hero-section p {
          font-size: 20px;
          opacity: 0.95;
        }

        /* Filters Section */
        .filters-section {
          background: white;
          padding: 32px 0;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .filters-wrapper {
          display: flex;
          gap: 16px;
          align-items: flex-end;
          flex-wrap: wrap;
        }

        .search-box {
          flex: 1;
          min-width: 250px;
          position: relative;
          display: flex;
          align-items: center;
        }

        .search-box :global(svg) {
          position: absolute;
          left: 16px;
          color: #666;
        }

        .search-box input {
          width: 100%;
          padding: 12px 16px 12px 48px;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 15px;
          transition: all 0.3s;
        }

        .search-box input:focus {
          outline: none;
          border-color: #7ec850;
        }

        .filter-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
          min-width: 200px;
        }

        .filter-group label {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 14px;
          font-weight: 600;
          color: #333;
        }

        .filter-group select {
          padding: 12px 16px;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 14px;
          cursor: pointer;
          transition: all 0.3s;
          background: white;
        }

        .filter-group select:focus {
          outline: none;
          border-color: #7ec850;
        }

        .reset-btn {
          padding: 12px 24px;
          background: #f5f5f5;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 600;
          color: #666;
          cursor: pointer;
          transition: all 0.3s;
        }

        .reset-btn:hover {
          background: #7ec850;
          color: white;
          border-color: #7ec850;
        }

        .results-info {
          margin-top: 20px;
          font-size: 14px;
          color: #666;
          font-weight: 500;
        }

        /* Packages Section */
        .packages-section {
          padding: 60px 0;
        }

        .packages-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 32px;
        }

        .package-card {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
          transition: all 0.3s;
          cursor: pointer;
          display: flex;
          flex-direction: column;
        }

        .package-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
        }

        .package-image {
          position: relative;
          height: 250px;
          overflow: hidden;
        }

        .package-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s;
        }

        .package-card:hover .package-image img {
          transform: scale(1.1);
        }

        .price-badge {
          position: absolute;
          top: 16px;
          right: 16px;
          background: rgba(0, 0, 0, 0.8);
          color: white;
          padding: 8px 16px;
          border-radius: 20px;
          font-weight: 700;
          font-size: 18px;
          backdrop-filter: blur(10px);
        }

        .package-content {
          padding: 24px;
          display: flex;
          flex-direction: column;
          flex: 1;
        }

        .package-content h3 {
          font-size: 22px;
          font-weight: 700;
          color: #1a1a1a;
          margin-bottom: 12px;
          line-height: 1.3;
        }

        .location-tag {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 14px;
          color: #666;
          margin-bottom: 12px;
        }

        .location-tag :global(svg) {
          color: #7ec850;
        }

        .description {
          font-size: 14px;
          line-height: 1.6;
          color: #555;
          margin-bottom: 16px;
          flex: 1;
        }

        .package-meta {
          display: flex;
          gap: 20px;
          padding: 16px 0;
          border-top: 1px solid #f0f0f0;
          border-bottom: 1px solid #f0f0f0;
          margin-bottom: 16px;
        }

        .meta-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          color: #666;
        }

        .meta-item :global(svg) {
          color: #7ec850;
        }

        .view-details-btn {
          width: 100%;
          padding: 12px;
          background: linear-gradient(135deg, #7ec850, #92d668);
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
        }

        .view-details-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(126, 200, 80, 0.4);
        }

        /* No Results */
        .no-results {
          text-align: center;
          padding: 80px 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
        }

        .no-results h3 {
          font-size: 24px;
          color: #1a1a1a;
          margin: 0;
        }

        .no-results p {
          color: #666;
          margin: 0;
        }

        /* Loading Screen */
        .loading-screen {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 20px;
        }

        .spinner {
          width: 60px;
          height: 60px;
          border: 4px solid #f0f0f0;
          border-top: 4px solid #7ec850;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }

        /* Responsive */
        @media (max-width: 1024px) {
          .packages-grid {
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
          }
        }

        @media (max-width: 768px) {
          .hero-section h1 {
            font-size: 36px;
          }

          .hero-section p {
            font-size: 18px;
          }

          .filters-wrapper {
            flex-direction: column;
          }

          .search-box,
          .filter-group {
            width: 100%;
            min-width: unset;
          }

          .packages-grid {
            grid-template-columns: 1fr;
          }

          .container {
            padding: 0 20px;
          }

          .packages-section {
            padding: 40px 0;
          }
        }

        @media (max-width: 640px) {
          .hero-section {
            padding: 60px 0;
          }

          .hero-section h1 {
            font-size: 28px;
          }

          .package-content h3 {
            font-size: 20px;
          }
        }
      `}</style>
    </div>
  );
}
