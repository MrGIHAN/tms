export const validationRules = {
  email: [
    { required: true, message: 'Email is required' },
    { type: 'email', message: 'Please enter a valid email' }
  ],

  password: [
    { required: true, message: 'Password is required' },
    { min: 8, message: 'Password must be at least 8 characters' },
    {
      pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/,
      message: 'Password must contain uppercase, lowercase, number and special character'
    }
  ],

  confirmPassword: (fieldName = 'password') => [
    { required: true, message: 'Please confirm your password' },
    ({ getFieldValue }) => ({
      validator(_, value) {
        if (!value || getFieldValue(fieldName) === value) {
          return Promise.resolve();
        }
        return Promise.reject(new Error('Passwords do not match'));
      },
    }),
  ],

  fullName: [
    { required: true, message: 'Full name is required' },
    { min: 2, message: 'Name must be at least 2 characters' },
    { pattern: /^[a-zA-Z\s]+$/, message: 'Name can only contain letters and spaces' }
  ],

  phone: [
    { required: true, message: 'Phone number is required' },
    { 
      pattern: /^[+]?[(]?[0-9]{1,4}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,9}$/,
      message: 'Please enter a valid phone number'
    }
  ],

  required: (fieldName) => [
    { required: true, message: `${fieldName} is required` }
  ]
};